# HYRAM GOLF — Play Internal Promotion Gate

Promotion is allowed only when all of these are evidenced:

- P0 FAIL = 0
- P0 BLOCKED = 0
- P0 NOT TESTED = 0
- `flutter analyze` exits 0
- all unit/widget tests exit 0
- Flutter integration flow exits 0 on Android
- Patrol native system-UI suite exits 0 on Android
- cold/warm launch, back, keyboard, rapid taps, rotation/font scale, background/resume and process-kill checks are observed on a Galaxy
- network loss/recovery is observed
- payment SUCCESS/CANCELLED/FAILED/TIMEOUT/PENDING/DUPLICATE paths do not create a false confirmed booking
- signed AAB builds successfully
- final Android applicationId/package name is approved before the first Play upload
- no production credential is embedded in the client

A Play upload is NOT evidence that the above gates passed.
Do not promote while any P0 row is BLOCKED or NOT TESTED.
