# RC23: GitHub Actions APK build

The workflow `.github/workflows/build-android-apk.yml` can build a **debug internal QA APK** on a GitHub-hosted Linux runner. It is intentionally manual (`workflow_dispatch`). The workflow checks analysis and both test modes before uploading the APK and SHA-256 as the `hyram-golf-qa-apk` artifact.

1. Upload the **contents** of the `hyram_rc9` folder to the root of a GitHub repository, keeping `.github/workflows/build-android-apk.yml` in place. Review the project before choosing repository visibility.
2. In the repository, open **Actions → Build HYRAM Android QA APK → Run workflow**.
3. Wait for every step to complete successfully, then download `hyram-golf-qa-apk` from the workflow run's **Artifacts** section.
4. Send the APK and the workflow log here for installation and QA review. A successful build does not establish that native permissions, provider integrations, or physical-device behavior pass.

This workflow has been checked for local YAML shape and command sequence only. It has **not** been run on GitHub, and no APK is included in this package. The first failing step must be treated as FAIL or BLOCKED, fixed, and rerun under the same conditions before marking it PASS.
