# HYRAM GOLF RC14 — Galaxy + iPhone readiness

## Applied changes
- Added iOS build preflight/gate (`tool/full_ios_gate.sh`) with internal and production unit runs, simulator compilation, and unsigned release compilation. It exits BLOCKED with code 2 on a non-macOS host.
- Added an iPhone-only Apple login entry whose internal QA mode is a sandbox identity; production still refuses login until server verification is connected.
- Health source labels now distinguish iOS HealthKit and Android Health Connect. The example integration configuration no longer presents missing providers as enabled or implies a universal three-year retention period.
- Maintained Android gate and the source release checks; added the platform release matrix.

## Observed reruns here
- Source invariants 12/12 PASS; Bash gate syntax PASS; example JSON parsing PASS.
- Android gate: BLOCKED, exit 2, Flutter not installed.
- iOS gate: BLOCKED, exit 2, macOS/Xcode required.
- Neither platform has a generated native host in the uploaded source. No physical phone, signed build, backend, merchant account or supplier API was available.

## Release condition
Each row of `MOBILE_RELEASE_MATRIX_RC14.csv` requires an executed PASS with build/test/device/provider evidence. The current project is a fail-closed cross-platform prototype and is not ready to publish as a working commercial booking/payment app. Existing Patrol permission tests do not actually trigger a native permission dialog and must be replaced when a real permission implementation exists.
