# HYRAM GOLF v7 TEST

## Test goals
1. Senior-friendly easy mode: large text, large tap targets, plain Korean labels.
2. Discount integrity: member/pro/partner/coupon rules are calculated before payment and revalidated server-side in production.
3. Booking flow: nationwide screen booking, practice range booking/payment, golf course booking.
4. Round flow: Golfzon connector placeholder -> score/NASMO import when official partnership/API is available.
5. MY BAG: club registration -> swing/round feedback context.
6. Admin: representatives Park Hyung-gyu and Kim Ha-ram can review operations/revenue; sensitive raw credentials/payment data remain hidden.

## Test discount rules in this prototype
- General member: list price.
- Pro verified: 10% screen / 15% practice range / 5% golf course (sample policy, configurable by admin).
- Partner discount: optional 5%; stacking policy is configurable. Current demo uses best-discount-only to avoid accidental over-discounting.
- Coupons: demo 3,000 KRW; production requires server validation, expiry, minimum-spend, and one-time-use checks.

## Production gate
Mock booking/payment must be replaced with official partner sandbox/production APIs. Never trust a client-computed discount or payment total; server recalculates and signs the final order amount.
