# Chrome location setting screenshots — RC19

- 6833.jpg: downloaded content URI mobile QA page, HYRAM app marked not installed, browser origin blocked.
- 6835.jpg: Chrome site settings list location as Ask first.
- 6837.jpg: Chrome site location requests allowed, unwanted requests collapsed.

These screenshots establish Chrome permission settings only. They do not show an HYRAM app installation, app switch, native OS prompt, grant, or denial. `content://downloads` remains an unsuitable origin for browser geolocation. HYRAM app permission gate: BLOCKED pending an installable build and real device run.
