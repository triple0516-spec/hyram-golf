# RC21 mobile QA screenshots

6862.jpg shows device Galaxy SM-A175N / Android 16, and explicitly reports HYRAM app installation as `미설치` and app version as not installed. 6864.jpg records that native denial could not be checked; status remains NOT TESTED. 6867.jpg shows a free-text `정상종료` note while the resume status remains NOT TESTED. The note is not executable evidence of an HYRAM app run.

Determination: native allow/deny/resume gates BLOCKED by uninstalled application. Mobile QA form now sets these gates to BLOCKED and disables their status selectors when installation is marked `미설치`; evidence export records a separate appPermissionVerdict. Recheck: source assertions and JavaScript syntax PASS. Mobile browser rerun and native app checks remain NOT TESTED.
