# Galaxy browser QA screenshots — RC18

- 6812.jpg: downloaded HTML test opened at `content://downloads`, app permission fields still NOT TESTED.
- 6820.jpg and 6822.jpg: Samsung accessibility/theme settings; do not establish HYRAM permission behavior.
- 6824.jpg: blank Chrome tab at `content://downloads`; no HYRAM app evidence.
- 6827.jpg and 6829.jpg: browser geolocation test reports `User denied Geolocation` code 1; long line causes horizontal overflow. The permission result belongs to Chrome on a downloaded content URI. It cannot be attributed to the HYRAM app or classified as app FAIL/PASS.

Fix applied to HYRAM_GOLF_mobile_QA.html: detect content/file URLs as BLOCKED for browser location, explain code 1 without attributing cause, and wrap long status text within mobile viewport. JavaScript syntax and source regression PASS. Real phone browser rerun of the updated HTML remains NOT TESTED. Native HYRAM app permission remains NOT TESTED pending installed signed build.
