# RC20 Galaxy location settings and app inventory

Screenshots 6837 and 6841–6855 show Chrome site location settings, the mobile QA form, system location service enabled, and application location permission lists. The visible lists contain Chrome and ChatGPT but do not show HYRAM. Some views are partial; absence of HYRAM in the visible portion is not definitive proof of non-installation. No screenshot shows an HYRAM app launch, permission prompt or resulting app behavior.

Observed evidence: device location setting enabled, Chrome site requests allowed, QA form accessible. HYRAM native grant and denial gates: BLOCKED or NOT TESTED pending installable HYRAM build and observed in-app flow. App release verdict stays NOT READY. The mobile QA form now prioritizes installed-app evidence and collapses the unrelated Chrome browser experiment.
