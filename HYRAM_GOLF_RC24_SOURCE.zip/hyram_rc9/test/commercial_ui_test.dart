import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:hyram_golf/core/app_environment.dart';
import 'package:hyram_golf/screens/booking_screen.dart';
import 'package:hyram_golf/screens/payment/commercial_checkout_screen.dart';
import 'package:hyram_golf/screens/signup_screen.dart';

void main() {
  testWidgets('booking samples only appear in internal mode', (tester) async {
    await tester.pumpWidget(const MaterialApp(home: Scaffold(body: BookingScreen())));
    if (HyramEnvironment.isInternal) {
      expect(find.textContaining('[QA 예시]'), findsWidgets);
      expect(find.text('예약 테스트'), findsWidgets);
    } else {
      expect(find.textContaining('[QA 예시]'), findsNothing);
      expect(find.text('실시간 예약 공급처 연결 전입니다. 예약 가능 시간과 가격은 아직 표시할 수 없습니다.'), findsOneWidget);
    }
  });

  testWidgets('production checkout cannot simulate or start payment', (tester) async {
    await tester.pumpWidget(const MaterialApp(home: CommercialCheckoutScreen()));
    if (!HyramEnvironment.isInternal) {
      expect(find.text('내부 QA 결제 결과'), findsNothing);
      expect(find.text('160,000원'), findsNothing);
      final button = tester.widget<FilledButton>(find.widgetWithText(FilledButton, '결제 연동 전'));
      expect(button.onPressed, isNull);
    } else {
      expect(find.text('내부 QA 결제 결과'), findsOneWidget);
    }
  });

  testWidgets('production signup does not pretend to create accounts', (tester) async {
    await tester.pumpWidget(const MaterialApp(home: SignupScreen()));
    final button = tester.widget<FilledButton>(find.widgetWithText(FilledButton, '계속'));
    expect(button.onPressed == null, !HyramEnvironment.isInternal);
  });
}
