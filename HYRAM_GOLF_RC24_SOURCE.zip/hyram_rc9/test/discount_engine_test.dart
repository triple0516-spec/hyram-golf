import 'package:flutter_test/flutter_test.dart';
import 'package:hyram_golf/services/discount_engine.dart';

void main(){
  test('no discount keeps base price',(){
    final r=DiscountEngine.calculate(const DiscountInput(basePrice:200000));
    expect(r.finalPrice,200000); expect(r.saved,0);
  });
  test('non-stack chooses largest benefit',(){
    final r=DiscountEngine.calculate(const DiscountInput(
      basePrice:200000,proRate:10,tierRate:5,couponAmount:30000,membershipAmount:10000));
    expect(r.finalPrice,170000); expect(r.applied,['쿠폰']);
  });
  test('invalid input is rejected instead of becoming a quote',(){
    expect(()=>DiscountEngine.calculate(const DiscountInput(basePrice:-1)),throwsArgumentError);
    expect(()=>DiscountEngine.calculate(const DiscountInput(basePrice:100,proRate:101)),throwsArgumentError);
    expect(()=>DiscountEngine.calculate(const DiscountInput(basePrice:100,couponAmount:-1)),throwsArgumentError);
  });
  test('stack never creates negative final price',(){
    final r=DiscountEngine.calculate(const DiscountInput(
      basePrice:10000,proRate:100,couponAmount:50000,allowStack:true));
    expect(r.finalPrice,0); expect(r.saved,10000);
  });
}
