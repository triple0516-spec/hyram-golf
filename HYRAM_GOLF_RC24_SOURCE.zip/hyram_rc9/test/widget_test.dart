import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:hyram_golf/main.dart';

void main() {
  testWidgets('HYRAM starts on the login screen without framework errors', (tester) async {
    await tester.pumpWidget(const HyramGolfApp());
    await tester.pumpAndSettle();
    expect(find.byType(TextField), findsNWidgets(2));
    expect(find.widgetWithText(FilledButton, '로그인'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });
}
