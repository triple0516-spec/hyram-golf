import 'package:flutter_test/flutter_test.dart';
import 'package:hyram_golf/services/integration_services.dart';
import 'package:hyram_golf/services/permission_policy.dart';
import 'package:hyram_golf/core/app_environment.dart';

void main() {
  test('all social sandbox adapters return a member', () async {
    final adapters=<AuthProviderAdapter>[
      KakaoAuthAdapter(), NaverAuthAdapter(), LineAuthAdapter(), GoogleAuthAdapter(), AppleAuthAdapter()
    ];
    for(final a in adapters){
      if (HyramEnvironment.isInternal) {
        final p=await a.signIn();
        expect(p, isNotNull);
        expect(p!.provider, isNotEmpty);
      } else {
        await expectLater(a.signIn(mode:AdapterMode.sandbox), throwsA(isA<StateError>()));
      }
    }
  });

  test('production payment remains locked without credentials', () async {
    expect(
      () => PaymentAdapter().pay(
        provider:'Samsung Pay',amount:160000,orderId:'QA',
        mode:AdapterMode.productionLocked,
      ),
      throwsA(isA<StateError>()),
    );
  });

  test('production default social adapters remain locked', () async {
    if (HyramEnvironment.isInternal) return;
    for (final adapter in <AuthProviderAdapter>[GoogleAuthAdapter(), KakaoAuthAdapter(), NaverAuthAdapter(), LineAuthAdapter(), AppleAuthAdapter()]) {
      await expectLater(adapter.signIn(), throwsA(isA<StateError>()));
    }
  });

  test('explicit sandbox payment is blocked in production', () async {
    if (!HyramEnvironment.isInternal) {
      await expectLater(PaymentAdapter().pay(provider:'Samsung Pay',amount:160000,orderId:'QA',mode:AdapterMode.sandbox), throwsA(isA<StateError>()));
      await expectLater(PaymentAdapter().pay(provider:'Samsung Pay',amount:160000,orderId:'QA'), throwsA(isA<StateError>()));
    }
  });

  test('optional permission denial keeps core app available', () {
    for(final d in PermissionPolicy.deniedFallback.values){
      expect(d.coreAppAvailable, isTrue);
      expect(d.fallback, isNotEmpty);
    }
  });
}
