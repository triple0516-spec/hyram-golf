import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';
import 'package:hyram_golf/main.dart';

void main(){
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  testWidgets('login -> home -> booking -> checkout -> range -> my hyram', (tester) async {
    await tester.pumpWidget(const HyramGolfApp());
    await tester.pumpAndSettle();

    expect(find.text('로그인'), findsWidgets);
    await tester.enterText(find.byType(TextField).at(0), 'qa@hyram.golf');
    await tester.enterText(find.byType(TextField).at(1), '12345678');
    await tester.tap(find.widgetWithText(FilledButton,'로그인'));
    await tester.pumpAndSettle();

    expect(find.text('HOME'), findsOneWidget);
    expect(find.text('SILVER MEMBER'), findsOneWidget);

    await tester.tap(find.text('BOOKING'));
    await tester.pumpAndSettle();
    expect(find.text('부킹 · 타석 · 결제'), findsOneWidget);

    await tester.tap(find.text('예약').first);
    await tester.pumpAndSettle();
    expect(find.text('결제'), findsOneWidget);
    expect(find.text('내부 QA 결제 결과'), findsOneWidget);

    await tester.pageBack();
    await tester.pumpAndSettle();
    await tester.tap(find.text('RANGE'));
    await tester.pumpAndSettle();
    expect(find.text('MY DRIVING RANGE'), findsOneWidget);

    await tester.tap(find.text('MY HYRAM'));
    await tester.pumpAndSettle();
    expect(find.text('내 정보 · 연결 · 차량'), findsOneWidget);
  });
}
