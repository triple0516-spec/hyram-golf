import 'package:flutter/material.dart';
import 'package:patrol/patrol.dart';
import 'package:hyram_golf/main.dart';

void main() {
  patrolTest('native permission denial never blocks core app', ($) async {
    await $.pumpWidgetAndSettle(const HyramGolfApp());

    await $(TextField).at(0).enterText('qa@hyram.golf');
    await $(TextField).at(1).enterText('12345678');
    await $('로그인').tap();
    await $.pumpAndSettle();

    await $(Switch).first.tap();
    await $.platform.mobile.denyPermission();
    await $.pumpAndSettle();

    expect($('HOME'), findsOneWidget);
  });

  patrolTest('native permission grant keeps app responsive', ($) async {
    await $.pumpWidgetAndSettle(const HyramGolfApp());

    await $(TextField).at(0).enterText('qa@hyram.golf');
    await $(TextField).at(1).enterText('12345678');
    await $('로그인').tap();
    await $.pumpAndSettle();

    await $(Switch).first.tap();
    await $.platform.mobile.grantPermissionWhenInUse();
    await $.pumpAndSettle();

    expect($('HOME'), findsOneWidget);
  });

  patrolTest('Android back navigation does not freeze app', ($) async {
    await $.pumpWidgetAndSettle(const HyramGolfApp());
    await $(TextField).at(0).enterText('qa@hyram.golf');
    await $(TextField).at(1).enterText('12345678');
    await $('로그인').tap();
    await $.pumpAndSettle();

    await $('BOOKING').tap();
    await $.pumpAndSettle();
    await $('예약').first.tap();
    await $.pumpAndSettle();

    await $.platform.mobile.pressBack();
    await $.pumpAndSettle();
    expect($('부킹 · 타석 · 결제'), findsOneWidget);
  });
}
