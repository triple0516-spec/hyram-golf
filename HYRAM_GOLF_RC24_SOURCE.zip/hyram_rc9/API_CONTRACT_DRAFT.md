# Backend API contract draft
POST /v1/auth/identity/start
POST /v1/auth/identity/verify
POST /v1/auth/signup
POST /v1/auth/login
POST /v1/pro-licenses
GET  /v1/pro-licenses/me
GET  /v1/home
GET  /v1/venues?type=&lat=&lng=&region=
GET  /v1/availability?venue_id=&date=
POST /v1/quotes
POST /v1/orders
POST /v1/payments/confirm
POST /v1/webhooks/payments/{provider}
POST /v1/bookings
POST /v1/bookings/{id}/cancel
GET  /v1/clubs
POST /v1/clubs
PATCH /v1/clubs/{id}
GET  /v1/driving-range/dashboard
GET  /v1/me/benefits
GET  /v1/admin/revenue
POST /v1/admin/pro-licenses/{id}/approve
POST /v1/admin/royal/{user_id}/approve

Rules:
- All monetary amounts are integer KRW.
- Quote has expiry + rule version.
- Order uses idempotency key.
- Client cannot submit trusted final price.
- Provider webhooks are signature verified.
