# RC15 final release evidence requirements

Status terms: PASS requires a real execution artifact matching the expected outcome; FAIL means a run contradicted it; BLOCKED means an input/tool/provider is missing; NOT TESTED means no run was made. Do not reinterpret BLOCKED or NOT TESTED as PASS.

| Gate | Run and capture | PASS criterion |
|---|---|---|
| Shared source and unit | `python3 tool/collect_release_evidence.py` and both internal/production Flutter tests | Exit 0, versioned logs, exact source revision and zero unexpected test failures |
| Android build | On configured Linux/macOS host run `bash tool/full_internal_gate.sh`; retain `flutter doctor -v`, analyze/test logs, APK/AAB checksum and signing certificate identity | All compilation and unit/integration runs exit 0; signing and package identity match approved release |
| Galaxy native and usability | On identified Galaxy OS model run permission allow/deny, gesture/back, network offline/restore, background/resume, force-stop/relaunch, large font, rotation, install/upgrade; record timestamp, OS/app build, steps and screen/video evidence | Expected state after each scenario; no crash, unauthorized access or false booking/payment confirmation |
| iOS build | On macOS with Xcode run `bash tool/full_ios_gate.sh`; retain Xcode/Flutter output, simulator/device IDs, signing entitlements, IPA checksum | Analyze/tests/build exit 0; signed IPA installs/updates on an actual iPhone; bundle ID and signing match approved release |
| iPhone native and usability | On identified iPhone/iOS run permission allow/deny, back gesture, network offline/restore, background/resume, force-quit/relaunch, Dynamic Type and install/upgrade; retain steps and screen/video evidence | Expected state in every scenario; no crash or misleading success message |
| OAuth and admin | Provider test accounts for both platforms, backend token verification logs, invalid/expired/replayed token cases, role authorization tests | Genuine login round trip works; invalid tokens and nonadmin requests rejected server side |
| Booking/price | Supplier test environment request/response IDs, unavailable slot, concurrency, retry, quote expiry and idempotency evidence | Only confirmed inventory yields a server booking, quoted price rechecked, no duplicate reservation |
| PG/refund | Merchant sandbox transaction IDs, signed webhook acceptance/rejection, duplicate callback, timeout, cancellation, refund and reconciliation logs | Server verified approval precedes confirmation; failures/pending never presented as paid |
| Privacy and permissions | API export/deletion traces, retention job records by data category, iOS/Android permission prompts and denial fallback | Data rights work, background retention follows approved policy, optional denial preserves core flows |
| Store readiness | Store metadata/privacy disclosures, device compatibility, signed distribution test and review record | Approved production configuration contains no QA identity, credentials, sample supply or sandbox successes |

Evidence artifacts must omit access tokens, real card data, user identifiers and private health data. Store redacted request IDs, anonymized screenshots and hashes. A gate owner records PASS only after checking the actual logs and replaying any fixed FAIL in the same conditions.

## Current final run
See `release_evidence/manifest.json` and the four logs. Source and Bash syntax PASS. Android and iOS execution BLOCKED. Provider, device, privacy, signing and commercial operations remain BLOCKED/NOT TESTED. **Overall verdict: NOT READY.**
