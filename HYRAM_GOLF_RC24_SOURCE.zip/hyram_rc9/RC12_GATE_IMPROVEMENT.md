# RC12 gate improvement and evidence

The executable gate now checks that flutter, dart and adb exist and that an authorized Android device is present before changing project files or reporting progress. It runs unit tests in both internal and production modes, and aligns the Patrol CLI pin with the pubspec constraint (4.10.0). Production tests now exercise default and explicit sandbox auth/payment paths.

Recheck in this runtime:
- `bash -n tool/full_internal_gate.sh`: PASS.
- `bash tool/full_internal_gate.sh`: exit code 2, `BLOCKED: flutter is missing; executable QA cannot be marked PASS.` This is the expected observed failure of the environment preflight.
- Gate source assertion for dual-mode coverage and CLI pin: PASS.

Flutter compilation, the Dart tests, native permission dialogs, device usability and partner-backed booking/payment still need execution. The current Patrol permission tests cannot pass meaningfully until a real permission request is wired and triggered within each test; do not report native gate PASS before then.
