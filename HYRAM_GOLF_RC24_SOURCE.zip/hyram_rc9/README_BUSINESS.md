# HYRAM GOLF — Business RC1

이 패키지는 v12 프로토타입을 사업화 기준으로 정리한 **상용화 소스 베이스 + 운영 명세**입니다.

중요: 실제 돈을 받는 운영판이 완성됐다는 뜻은 아닙니다.
PG/본인인증/예약 파트너/KPGA·KLPGA·Golfzon 등 외부 서비스 계약과 서버 자격증명이 없기 때문에 해당 연결은 production gate로 분리되어 있습니다.

포함:
- 기존 Flutter UI/Navigation
- KPGA/KLPGA 프로 라이선스 플로우
- 상용 할인 계산 모듈 초안
- CommercialConfig
- 사업화 제품 명세
- Backend API 계약 초안
- 보안/개인정보 체크리스트
