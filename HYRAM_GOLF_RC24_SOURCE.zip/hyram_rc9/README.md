# HYRAM GOLF — Commercial UX Build v2

대표자: **박형규 · 김하람**

HYRAM GOLF는 골프장/스크린/타석 부킹, 결제, 라운드 자동 스코어, 나스모/스윙, 건강·위치·주차·차량, SNS/메신저, Grok FUN MODE, 대표자 통합 모니터링을 하나의 프리미엄 UX로 묶는 상용 앱용 Flutter 기반 프로젝트입니다.

## 핵심 UX
- 익숙한 로그인: Google / Kakao / Apple + LINE 연결지점
- 홈: 골프장 부킹 / 스크린 부킹 / 간편결제 타석 / 오늘 스코어 / 나스모 / 내 스윙 / 개선 리포트 / Grok
- 부킹: 골프장·스크린·타석 3탭
- 라운드: 라운드 종료 후 제휴 시스템에서 자동 스코어 import 구조
- AI: 오늘 스코어·나스모·문제점 개선을 Grok FUN MODE로 피드백
- 주차: 주차면 현황 + 차량 등록 상태
- 대표자: 박형규·김하람 전용 관리자 화면
- 데이터: 기본 3년 보관/자동폐기 job 설계

## 최신 연동 기준
2026-09 기준 확인된 문서에 맞춰 Google Sign-In 7.2.0, Kakao Flutter SDK 2.0.1, Sign in with Apple 8.2.0을 기준으로 의존성을 갱신했습니다. Google Android의 구형 Google Sign-In은 Credential Manager로의 이전이 권장됩니다.

Toss Payments는 Android/iOS SDK의 결제 승인 흐름을 사용하고, 카드사 앱은 PG/앱투앱 호출 방식으로 연결합니다. LINE은 사용자의 요청대로 실제 SDK를 고정하지 않고 connector-only 지점으로 남겼습니다.

## 반드시 필요한 서버/사업자 설정
1. OAuth 앱 등록 및 redirect URI 설정
2. 카카오/구글/애플 client ID 및 server-side token verification
3. Toss Payments / KakaoPay 등 PG·가맹점 계약 및 webhook
4. 골프장·스크린·타석 예약 API 제휴
5. 주차/차량 API 제휴
6. HealthKit/Health Connect 권한 및 개인정보 처리
7. Grok API key를 서버에서만 보관
8. 대표자/직원 RBAC와 감사로그

## 실행
Flutter 3.38+ / Dart 3.9+ 환경에서 `flutter pub get` 후 Android Studio 또는 Xcode에서 실행하세요.

이 저장소는 실제 비밀키를 포함하지 않습니다. 현재 화면과 connector는 동작 가능한 프로토타입이며, 외부 사업자 계정과 백엔드가 연결되면 실서비스 플로우로 전환할 수 있습니다.
