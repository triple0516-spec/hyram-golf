# Payment / App-to-App integration notes

Use provider SDK/PG checkout first. Where app-to-app payment is required, register only the schemes required by the selected provider and platform. Do not hardcode card credentials.

Examples documented by Toss Payments include Toss Pay, KB, NH, Hyundai and ISP/BC app schemes. iOS and Android app-link handling differ; keep them in native platform adapters.
