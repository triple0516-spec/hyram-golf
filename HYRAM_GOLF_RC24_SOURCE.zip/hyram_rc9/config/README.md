# Production integration checklist

- Google: OAuth client IDs + Android SHA-1/SHA-256 + iOS URL scheme.
- Kakao: Native App Key + Android/iOS package/bundle IDs + redirect settings.
- LINE: LINE Login channel + redirect URI + native platform setup. The Dart adapter is intentionally a safe placeholder until the selected LINE SDK/version is fixed.
- KakaoTalk: sharing/chat integrations require approved Kakao APIs and scopes.
- Instagram/Facebook: Meta app + permissions + platform review where required.
- KakaoPay/TossPayments: merchant onboarding, PG/webhook configuration, server-side payment verification.
- Cards/bank account: normally through the chosen PG/open-banking provider; never collect raw card/bank credentials in your own database unless legally and technically permitted.
- Health: iOS HealthKit and Android Health Connect permissions + store review disclosures.
- Location/SOS: OS permissions, consent screen, emergency contact flow, terms, and safety/legal review.
- Grok: server-side proxy, key management, rate limits, privacy controls.
