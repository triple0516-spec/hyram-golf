# HYRAM GOLF RC5 Android Validation Candidate

## Login
- Kakao / Naver / LINE / Google only.
- Apple login removed from Android login flow.
- Social token/profile must be verified/linked by backend before HYRAM session creation.
- Login cancellation and provider failure must return to login without blocking app restart.

## Permission behavior
No optional runtime permission is requested at first launch.
- Location: request only after nearby search. Denied => manual region selector.
- Notification: denied => booking/status remains visible in app.
- Health: opt-in only. Denied => core booking/membership/club features continue.
- Camera: request only when a camera feature is invoked; otherwise gallery/manual fallback.
- Permanent denial => explain limitation and offer Settings action; never loop permission dialogs.

## Golden path
Login -> personalized HOME -> booking -> quote -> benefits -> payment -> confirmation
-> RANGE -> MY CLUB -> MY HYRAM.

## Android verification gates
P0 must pass on a physical Galaxy before release:
- cold start / warm start / background-resume
- Android back and predictive-back behavior
- keyboard open/close and small/large display font
- 10x rapid taps on login/booking/payment actions
- Wi-Fi <-> mobile network switch
- offline during booking and payment result recovery
- location deny once / deny twice / revoke from Settings
- notification deny
- app process kill during payment and booking
- payment success/cancel/failure/timeout
- duplicate order and duplicate webhook protection
- full/partial refund
- screen rotation where supported
- accessibility labels/touch targets

## Release status
STATIC VALIDATION: candidate-ready.
PHYSICAL GALAXY VALIDATION: NOT YET EXECUTED.
APK/AAB: NOT BUILT in this environment until Flutter/Android SDK/ADB are available.
Do not mark Android Verified until the physical-device P0 matrix passes.
