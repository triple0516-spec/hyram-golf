# RC16 — errors addressed and exact evidence still missing

## Implemented and rechecked
- Location switch now calls Geolocator foreground location permission and handles service-disabled/denied results without claiming consent. Android and iOS generated host files receive foreground location declarations through an idempotent configuration script. Patrol permission cases now tap the location switch before handling the OS prompt.
- Added production/internal Flutter widget tests for booking samples, checkout simulation and signup restrictions. These are authored but **not executed** here because Flutter is unavailable.
- Native host fixtures prove the Android manifest and iOS plist modifications are parseable, preserve unrelated entries and remain singular after two runs. `release_evidence/mobile_host_fixture.log`: PASS.
- Build gates now run toolchain analysis, tests and compilation before requiring a physical Android device. iOS simulator availability is checked after shared unit tests.

## Evidence recorded in this workspace
- `release_evidence/manifest.json`: source PASS, mobile host fixture PASS, shell syntax PASS, Android BLOCKED (Flutter absent), iOS BLOCKED (non-macOS/Xcode absent).
- The source gate checks a narrow set of invariants; it is not Dart compile or native behavior evidence.

## Remaining release blockers
1. Flutter/Dart/Android SDK installation on an Android build host, generated Android host, signed AAB, physical Galaxy and native permission test rerun. Ensure location services enabled and app permissions reset before each grant/deny test.
2. macOS/Xcode/CocoaPods/Flutter host, generated iOS Runner, signed IPA and real iPhone for permission, dynamic type, background, deep links and Apple login reruns.
3. Provider-backed OAuth identity and server RBAC, booking inventory and idempotent quote/order APIs, merchant payment/webhook/refund and account privacy endpoints.
4. Store signing and disclosures, app install/upgrade, manual Galaxy/iPhone interaction and network state evidence.

**Commercial readiness verdict: NOT READY.** The code has fail-closed boundaries for disconnected services. Granting the missing permissions or changing this verdict requires real execution and provider evidence, not a source-only assertion.
