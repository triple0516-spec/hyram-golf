# HYRAM GOLF v11 Detail Build

추가된 핵심: KPGA 라이선스 인증 구조, 프로 여부 질문 제거, Hybrid First 데이터 연결 설계, MY DRIVING RANGE, MY CLUB 상세 데이터 모델, 확장 HOME 제품 명세.

이 패키지는 Flutter 소스/제품 명세입니다. 실제 KPGA·Health Connect·HealthKit·골프 서비스 연결에는 각 제공자의 승인/SDK/API와 서버 구현이 추가로 필요합니다.
