# RC22 Android APK build status

## Same-command rerun

Run `bash tool/build_android_apk.sh` from the project root on a Linux host with access to GitHub, Google Android downloads, Flutter artifact storage, pub.dev and Maven/Gradle repositories. The script installs local Flutter and Android command-line tools, generates `android/` using Flutter, applies location permissions, then runs analysis, both test modes, and a debug APK build. It verifies that the APK exists and prints its SHA-256.

## Observed in this environment

- PASS: `bash -n tool/build_android_apk.sh` and `python3 tool/source_release_checks.py`.
- PASS: Flutter stable repository and Android command-line tools archive downloaded. Flutter began downloading its Dart SDK.
- BLOCKED: `bash tool/build_android_apk.sh` exited 2 at the pub.dev reachability gate: proxy CONNECT timed out. Flutter tool dependency resolution also stalled at `Resolving dependencies...` during the initial run.
- NOT TESTED: generated Android runner, `flutter pub get`, `flutter analyze`, Flutter tests, Gradle compilation, APK output and device installation.

Do not mark the APK or device gates PASS until the full script completes and the APK is installed and exercised on a device under the intended conditions. This bundle contains source and a build script, not an APK.
