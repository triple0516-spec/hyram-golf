# HYRAM GOLF 상용 UX 명세

## Roles
- Representative: 박형규, 김하람 — 전체 운영 데이터 접근, 연동 상태, 예약/결제/회원/데이터 보관 모니터링
- Staff — 운영 범위별 접근
- Member — 본인 데이터/예약/결제/스코어/건강/차량

## Booking
- 골프장 부킹
- 스크린 부킹
- 간편결제 타석현황
- 예약 상태 / 취소 / 환불 / webhook

## Round
- 라운드 종료 이벤트
- 제휴 시스템 또는 스코어카드 API에서 자동 import
- 중복 방지용 roundId + sourceId idempotency
- 수동 수정 가능, 수정 감사로그 저장

## Golf intelligence
- 오늘 스코어
- 나스모 영상 등록
- 스윙 메모/측정치
- 반복 문제점
- 개선 플랜
- Grok FUN MODE

## Mobility
- 차량 등록 여부
- 주차장 잔여면
- 골프장 도착 시 차량/주차 연계

## Privacy
- 기본 데이터 보관 3년
- purge_at 계산 후 자동 삭제/익명화 job
- 법정 보존 의무가 있는 결제/회계 데이터는 별도 retention policy

## Security
- 대표자 권한 서버 검증
- OAuth token server verification
- payment secrets / Grok key server-only
- 건강/위치/SOS는 최소권한 및 감사로그
