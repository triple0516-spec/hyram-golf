#!/usr/bin/env python3
"""Limited source invariants; never substitutes for Flutter/device/provider tests."""
from pathlib import Path
root = Path(__file__).resolve().parent.parent
read = lambda name: (root / name).read_text(encoding='utf-8')
checks = {
    'production default': "defaultValue: 'production'" in read('lib/core/app_environment.dart'),
    'all auth/payment adapters locked outside internal': read('lib/services/integration_services.dart').count('if (!HyramEnvironment.isInternal || mode == AdapterMode.productionLocked) {') == 6,
    'production booking hides samples': all(f'HyramEnvironment.isInternal && tab=={i}' in read('lib/screens/booking_screen.dart') for i in range(3)),
    'production checkout disables payment': 'onPressed:HyramEnvironment.isInternal ? ()=>showDialog' in read('lib/screens/payment/commercial_checkout_screen.dart'),
    'production signup disabled': 'onPressed:HyramEnvironment.isInternal?next:null' in read('lib/screens/signup_screen.dart'),
    'admin route internal only': "'/admin':(_)=>HyramEnvironment.isInternal" in read('lib/main.dart'),
    'license submission internal only': "if (!HyramEnvironment.isInternal)" in read('lib/screens/pro/pro_license_screen.dart'),
    'club save internal only': 'onPressed:HyramEnvironment.isInternal ?' in read('lib/screens/driving_range/my_club_screen.dart'),
    'iOS Apple auth remains backend-gated': 'AppleAuthAdapter()' in read('lib/screens/auth_screen.dart') and 'class AppleAuthAdapter' in read('lib/services/integration_services.dart'),
    'native location request wired': 'Geolocator.requestPermission()' in read('lib/services/integration_services.dart') and 'await $(Switch).first.tap()' in read('patrol_test/native_system_ui_test.dart'),
    'platform foreground location host setup': all('configure_mobile_hosts.py' in read(f) for f in ['tool/full_internal_gate.sh', 'tool/full_ios_gate.sh']),
    'grok reachable': 'push(const AiScreen())' in read('lib/screens/home_screen.dart'),
    'no fabricated AI score': 'score:76' not in read('lib/screens/ai_screen.dart'),
    'dual-mode executable tests': all('Production unit/widget tests' in read(f) and 'Internal unit/widget tests' in read(f) for f in ['tool/full_internal_gate.sh','tool/full_internal_gate.ps1']),
}
for name, passed in checks.items():
    print(f"{'PASS' if passed else 'FAIL'} {name}")
if not all(checks.values()):
    raise SystemExit(1)
print('SOURCE INVARIANTS PASS; executable and provider gates remain separate.')
