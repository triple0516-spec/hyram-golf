#!/usr/bin/env bash
# Run from any directory. Installs user-local tools if the host permits downloads.
set -euo pipefail
cd "$(dirname "$0")/.."
tool_root="${HYRAM_TOOL_ROOT:-$HOME/.local/share/hyram-android}"
flutter_root="$tool_root/flutter"
android_root="${ANDROID_SDK_ROOT:-$tool_root/android-sdk}"
export ANDROID_SDK_ROOT="$android_root" ANDROID_HOME="$android_root"
export PATH="$flutter_root/bin:$android_root/cmdline-tools/latest/bin:$android_root/platform-tools:$PATH"

fail() { printf 'BLOCKED: %s\n' "$*" >&2; exit 2; }
fetch() {
  command -v curl >/dev/null || fail 'curl is required to download the Android tools.'
  curl --fail --location --retry 2 --connect-timeout 10 --max-time 600 "$1" -o "$2" ||
    fail "download failed: $1. Supply an installed SDK or allow access to this host."
}

command -v java >/dev/null || fail 'A full JDK 17 or newer is required (java missing).'
command -v javac >/dev/null || fail 'A full JDK 17 or newer is required (javac missing; JRE alone is insufficient).'

if ! command -v flutter >/dev/null; then
  command -v git >/dev/null || fail 'git is required for Flutter installation.'
  mkdir -p "$tool_root"
  git clone --depth 1 -b stable https://github.com/flutter/flutter.git "$flutter_root" ||
    fail 'Flutter download failed. Set HYRAM_TOOL_ROOT to a directory containing flutter/.'
fi
if ! command -v sdkmanager >/dev/null; then
  command -v unzip >/dev/null || fail 'unzip is required for Android command-line tools.'
  mkdir -p "$android_root/cmdline-tools/latest"
  archive="$tool_root/commandlinetools-linux-15859902_latest.zip"
  if [[ ! -f "$archive" ]]; then
    fetch 'https://dl.google.com/android/repository/commandlinetools-linux-15859902_latest.zip' "$archive"
  fi
  temp_dir="$(mktemp -d)"
  trap 'rm -rf "$temp_dir"' EXIT
  unzip -q "$archive" -d "$temp_dir"
  [[ -f "$temp_dir/cmdline-tools/bin/sdkmanager" ]] || fail 'Android tools archive has an unexpected layout.'
  cp -a "$temp_dir/cmdline-tools/." "$android_root/cmdline-tools/latest/"
fi
command -v java >/dev/null || fail 'JDK 17 or newer is required.'
if ! curl --head --fail --silent --show-error --connect-timeout 5 --max-time 12 \
  https://pub.dev/api/packages/collection >/dev/null; then
  fail 'pub.dev is unreachable; Flutter initialization and package resolution require access to pub.dev.'
fi
flutter --version
sdkmanager --sdk_root="$android_root" --licenses < <(yes) >/dev/null || fail 'Android SDK licenses could not be accepted.'
sdkmanager --sdk_root="$android_root" 'platform-tools' 'platforms;android-35' 'build-tools;35.0.0' || fail 'Android SDK package installation failed.'
flutter config --android-sdk "$android_root"
flutter create . --platforms=android --org com.hyram --project-name hyram_golf
python3 tool/configure_mobile_hosts.py android
flutter pub get
flutter analyze
flutter test test --dart-define=HYRAM_ENV=internal
flutter test test
flutter build apk --debug --dart-define=HYRAM_ENV=internal
apk='build/app/outputs/flutter-apk/app-debug.apk'
[[ -s "$apk" ]] || fail "build command returned without a nonempty APK at $apk"
sha256sum "$apk"
printf 'PASS: %s\n' "$PWD/$apk"
