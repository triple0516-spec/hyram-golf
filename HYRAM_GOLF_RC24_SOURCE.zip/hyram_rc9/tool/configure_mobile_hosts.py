#!/usr/bin/env python3
"""Configure generated Flutter hosts for foreground location; idempotent."""
import plistlib
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

root = Path(__file__).resolve().parent.parent
platform = sys.argv[1] if len(sys.argv) == 2 else ''
if platform not in {'android', 'ios'}:
    raise SystemExit('usage: configure_mobile_hosts.py android|ios')
if platform == 'android':
    path = root / 'android/app/src/main/AndroidManifest.xml'
    if not path.is_file():
        raise SystemExit('BLOCKED: generated AndroidManifest.xml missing')
    ET.register_namespace('android', 'http://schemas.android.com/apk/res/android')
    tree = ET.parse(path)
    manifest = tree.getroot()
    name = '{http://schemas.android.com/apk/res/android}name'
    for permission in ('android.permission.ACCESS_COARSE_LOCATION',):
        if not any(child.tag == 'uses-permission' and child.get(name) == permission for child in manifest):
            item = ET.Element('uses-permission')
            item.set(name, permission)
            manifest.insert(0, item)
    tree.write(path, encoding='utf-8', xml_declaration=True)
else:
    path = root / 'ios/Runner/Info.plist'
    if not path.is_file():
        raise SystemExit('BLOCKED: generated iOS Info.plist missing')
    with path.open('rb') as fh:
        info = plistlib.load(fh)
    info['NSLocationWhenInUseUsageDescription'] = '주변 골프장과 연습장을 찾을 때만 현재 위치를 사용합니다.'
    with path.open('wb') as fh:
        plistlib.dump(info, fh, sort_keys=False)
print(f'{platform}: foreground location declaration configured')
