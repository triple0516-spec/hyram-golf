#!/usr/bin/env python3
"""Exercise native host configuration using throwaway Android/iOS fixtures."""
import plistlib
import shutil
import subprocess
import tempfile
import xml.etree.ElementTree as ET
from pathlib import Path

source = Path(__file__).resolve().parent / 'configure_mobile_hosts.py'
with tempfile.TemporaryDirectory() as temporary:
    root = Path(temporary)
    (root / 'tool').mkdir()
    (root / 'android/app/src/main').mkdir(parents=True)
    (root / 'ios/Runner').mkdir(parents=True)
    shutil.copyfile(source, root / 'tool/configure_mobile_hosts.py')
    manifest = root / 'android/app/src/main/AndroidManifest.xml'
    manifest.write_text('<manifest xmlns:android="http://schemas.android.com/apk/res/android">'
                        '<application android:label="HYRAM"/></manifest>', encoding='utf-8')
    info = root / 'ios/Runner/Info.plist'
    info.write_bytes(plistlib.dumps({'CFBundleName': 'HYRAM'}))
    for platform in ('android', 'ios'):
        for _ in range(2):
            subprocess.run(['python3', str(root / 'tool/configure_mobile_hosts.py'), platform],
                           check=True, capture_output=True, text=True)
    tree = ET.parse(manifest)
    assert sum(element.tag == 'uses-permission' for element in tree.getroot()) == 1
    assert any(element.tag == 'application' for element in tree.getroot())
    output = plistlib.loads(info.read_bytes())
    assert output['CFBundleName'] == 'HYRAM'
    assert 'NSLocationWhenInUseUsageDescription' in output
print('Native host fixture and idempotence: PASS')
