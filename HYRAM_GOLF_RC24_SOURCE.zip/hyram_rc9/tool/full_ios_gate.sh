#!/usr/bin/env bash
set -euo pipefail
blocked(){ echo "BLOCKED: $1" >&2; exit 2; }
[[ "$(uname -s)" == Darwin ]] || blocked 'iOS builds require a macOS host with Xcode.'
for executable in flutter dart xcodebuild xcrun pod; do
  command -v "$executable" >/dev/null 2>&1 || blocked "$executable is missing."
done
xcodebuild -version
if [[ ! -d ios ]]; then
  flutter create . --platforms=ios --org com.hyram --project-name hyram_golf
fi
python3 tool/configure_mobile_hosts.py ios
flutter pub get
flutter analyze
flutter test test --dart-define=HYRAM_ENV=internal
flutter test test
xcrun simctl list devices available | grep -q 'iPhone' || blocked 'no available iPhone simulator.'
flutter build ios --simulator --dart-define=HYRAM_ENV=internal
flutter build ios --release --no-codesign
printf '%s\n' 'iOS compile/simulator build gates passed. Signed IPA, real iPhone behavior, entitlements and providers require separate evidence.'
