#!/usr/bin/env bash
set -euo pipefail
gate(){ echo; echo "=== $1 ==="; shift; "$@"; }
for executable in flutter dart; do
  if ! command -v "$executable" >/dev/null 2>&1; then
    echo "BLOCKED: $executable is missing; executable QA cannot be marked PASS." >&2
    exit 2
  fi
done
gate "Flutter version" flutter --version
gate "Flutter doctor" flutter doctor -v
if [ ! -d android ]; then
  gate "Generate Android host" flutter create . --platforms=android --org com.hyram --project-name hyram_golf
fi
gate "Configure Android foreground location" python3 tool/configure_mobile_hosts.py android
gate "Dependencies" flutter pub get
gate "Analyze" flutter analyze
gate "Internal unit/widget tests" flutter test test --dart-define=HYRAM_ENV=internal
gate "Production unit/widget tests" flutter test test
gate "Debug APK" flutter build apk --debug --dart-define=HYRAM_ENV=internal
gate "Release AAB compile" flutter build appbundle --release
command -v adb >/dev/null 2>&1 || { echo "BLOCKED: adb missing; device gate cannot run." >&2; exit 2; }
if ! adb devices | grep -Eq '^[^[:space:]]+[[:space:]]+device$'; then
  echo 'BLOCKED: no authorized Android device; native and device gates cannot run.' >&2
  exit 2
fi
gate "Flutter integration test" flutter test integration_test/app_flow_test.dart --dart-define=HYRAM_ENV=internal
command -v patrol >/dev/null 2>&1 || { echo "BLOCKED: Patrol CLI missing; native UI gate cannot run." >&2; exit 2; }
gate "Patrol native UI tests" patrol test --target patrol_test/native_system_ui_test.dart --dart-define=HYRAM_ENV=internal
echo "EXECUTABLE GATES PASSED; provider-backed and manual Galaxy scenarios require separate evidence."
