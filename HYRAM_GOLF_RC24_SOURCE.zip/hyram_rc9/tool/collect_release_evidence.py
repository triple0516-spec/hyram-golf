#!/usr/bin/env python3
"""Run available release gates and write evidence without inventing unavailable results."""
from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path
import json
import os
import platform
import subprocess
import sys

root = Path(__file__).resolve().parent.parent
out = root / 'release_evidence'
out.mkdir(exist_ok=True)

def run(key, args):
    try:
        result = subprocess.run(args, cwd=root, capture_output=True, text=True, timeout=3600,
                                env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'})
        content = (result.stdout + '\n' + result.stderr).strip()
        status = 'PASS' if result.returncode == 0 else 'BLOCKED' if result.returncode == 2 else 'FAIL'
        code = result.returncode
    except subprocess.TimeoutExpired as exc:
        content = f'timeout after {exc.timeout}s'
        status, code = 'FAIL', 124
    (out / f'{key}.log').write_text(content + '\n', encoding='utf-8')
    return {'status': status, 'exit_code': code, 'log': f'{key}.log',
            'sha256': sha256((content + '\n').encode()).hexdigest()}

results = {
    'source': run('source', [sys.executable, 'tool/source_release_checks.py']),
    'mobile_host_fixture': run('mobile_host_fixture', [sys.executable, 'tool/test_mobile_host_config.py']),
    'shell_syntax': run('shell_syntax', ['bash', '-n', 'tool/full_internal_gate.sh',
                                         'tool/bootstrap_android.sh', 'tool/full_ios_gate.sh']),
    'android': run('android', ['bash', 'tool/full_internal_gate.sh']),
    'ios': run('ios', ['bash', 'tool/full_ios_gate.sh']),
}
external = {
    'android_galaxy_native_permissions': 'NOT TESTED',
    'android_galaxy_touch_network_background': 'NOT TESTED',
    'ios_iphone_native_permissions': 'NOT TESTED',
    'ios_iphone_gesture_network_background': 'NOT TESTED',
    'oauth_backend_session_and_rbac': 'BLOCKED',
    'supplier_reservation_inventory': 'BLOCKED',
    'pg_webhook_refund_settlement': 'BLOCKED',
    'privacy_export_deletion_retention': 'BLOCKED',
    'signed_aab_and_ipa_distribution': 'BLOCKED',
}
source_files = sorted([root / 'pubspec.yaml'] + [f for directory in ('lib', 'test', 'integration_test', 'patrol_test', 'tool')
    for f in (root / directory).rglob('*') if f.is_file() and '__pycache__' not in f.parts])
source_digest = sha256()
for source_file in source_files:
    source_digest.update(source_file.relative_to(root).as_posix().encode())
    source_digest.update(b'\0')
    source_digest.update(source_file.read_bytes())
    source_digest.update(b'\0')
manifest = {'created_utc': datetime.now(timezone.utc).isoformat(),
            'host': platform.system(), 'source_tree_sha256': source_digest.hexdigest(),
            'executed': results, 'external': external,
            'verdict': 'PASS' if all(v['status'] == 'PASS' for v in results.values())
            and all(v == 'PASS' for v in external.values()) else 'NOT READY'}
(out / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
for key, value in results.items():
    print(f"{key}: {value['status']} (exit {value['exit_code']})")
print('Release verdict:', manifest['verdict'])
