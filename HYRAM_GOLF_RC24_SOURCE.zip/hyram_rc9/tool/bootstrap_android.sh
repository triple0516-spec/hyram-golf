#!/usr/bin/env bash
set -euo pipefail
command -v flutter >/dev/null || { echo "Flutter SDK 3.47 stable is required in PATH."; exit 2; }
flutter --version
flutter doctor -v
flutter create . --platforms=android --org com.hyram --project-name hyram_golf
flutter pub get
flutter analyze
flutter test --dart-define=HYRAM_ENV=internal
flutter build apk --debug --dart-define=HYRAM_ENV=internal
echo "APK: build/app/outputs/flutter-apk/app-debug.apk"
echo "Then: adb devices && adb install -r build/app/outputs/flutter-apk/app-debug.apk"
