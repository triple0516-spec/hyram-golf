$ErrorActionPreference = "Stop"
function Gate($name, [scriptblock]$cmd) {
  Write-Host "`n=== $name ==="
  & $cmd
  if ($LASTEXITCODE -ne 0) { throw "$name FAILED ($LASTEXITCODE)" }
}
foreach ($name in @("flutter", "dart")) {
  if (-not (Get-Command $name -ErrorAction SilentlyContinue)) { throw "BLOCKED: $name is missing; executable QA cannot be marked PASS." }
}
Gate "Flutter version" { flutter --version }
Gate "Flutter doctor" { flutter doctor -v }
if (-not (Test-Path "android")) {
  Gate "Generate Android host" { flutter create . --platforms=android --org com.hyram --project-name hyram_golf }
}
Gate "Configure Android foreground location" { python tool/configure_mobile_hosts.py android }
Gate "Dependencies" { flutter pub get }
Gate "Analyze" { flutter analyze }
Gate "Internal unit/widget tests" { flutter test test --dart-define=HYRAM_ENV=internal }
Gate "Production unit/widget tests" { flutter test test }
Gate "Debug APK" { flutter build apk --debug --dart-define=HYRAM_ENV=internal }
Gate "Release AAB compile" { flutter build appbundle --release }
if (-not (Get-Command adb -ErrorAction SilentlyContinue)) { throw "BLOCKED: adb missing; device gate cannot run." }
$devices = @(adb devices | Select-String '^\S+\s+device$')
if ($devices.Count -eq 0) { throw "BLOCKED: no authorized Android device; native and device gates cannot run." }
Gate "Flutter integration test" { flutter test integration_test/app_flow_test.dart --dart-define=HYRAM_ENV=internal }
if (-not (Get-Command patrol -ErrorAction SilentlyContinue)) { throw "BLOCKED: Patrol CLI missing; native UI gate cannot run." }
Gate "Patrol native UI tests" { patrol test --target patrol_test/native_system_ui_test.dart --dart-define=HYRAM_ENV=internal }
Write-Host "`nEXECUTABLE GATES PASSED; provider-backed and manual Galaxy scenarios require separate evidence."
