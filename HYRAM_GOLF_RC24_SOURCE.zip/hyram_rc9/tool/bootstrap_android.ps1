$ErrorActionPreference = "Stop"
Write-Host "HYRAM GOLF RC6 Android bootstrap"

if (-not (Get-Command flutter -ErrorAction SilentlyContinue)) {
  throw "Flutter SDK 3.47 stable을 설치하고 flutter/bin을 PATH에 추가한 뒤 다시 실행하세요."
}

flutter --version
flutter doctor -v

# Generate the Android host from the installed Flutter version.
flutter create . --platforms=android --org com.hyram --project-name hyram_golf

# Restore release identity/version if flutter create touched pubspec metadata.
flutter pub get
flutter analyze
flutter test --dart-define=HYRAM_ENV=internal
flutter test

Write-Host "Static checks passed. Building QA APK..."
flutter build apk --debug --dart-define=HYRAM_ENV=internal

Write-Host "APK: build/app/outputs/flutter-apk/app-debug.apk"
Write-Host "Connect Galaxy with USB debugging, then run:"
Write-Host "  adb devices"
Write-Host "  adb install -r build/app/outputs/flutter-apk/app-debug.apk"
