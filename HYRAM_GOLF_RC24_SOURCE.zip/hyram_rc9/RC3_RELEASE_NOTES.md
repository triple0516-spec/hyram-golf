# HYRAM GOLF Business RC3

## Login
간편 로그인 표시:
1. 카카오
2. 네이버
3. LINE
4. Google

Apple 로그인 UI/설계는 Android-first RC에서 제거.
실제 로그인 활성화에는 각 공급자의 Client ID/Secret, 앱 등록, Redirect URI,
서버 토큰 검증 및 계정 연결 정책이 필요함.

## Payment
표시 결제수단:
- Samsung Pay
- 신용·체크카드
- 카카오페이
- 네이버페이
- 토스페이

결제 UX:
서버 Quote → 기본가/혜택/최종가 표시 → 결제수단 선택 → 결제 동의 → 승인.
RC에서는 실제 과금하지 않음.

Samsung Pay:
앱에는 결제수단/어댑터 자리를 구현.
실제 활성화에는 Samsung Pay/PG 지원 여부, 가맹점 등록, 서비스 승인,
운영 자격증명과 지원 기기 테스트가 필요함.

## Google Play pre-release note
Android 앱의 로그인 선택은 위 4개로 단순화.
단, 향후 iOS 앱을 배포할 경우 Apple App Store의 로그인 관련 심사 요구사항을
별도로 재검토해야 함.

## Final QA gates
- 회원가입/로그인
- 뒤로가기/중복 탭/로딩/오류
- 예약 재고 변경
- 할인 재계산
- 결제 성공/실패/취소/중복 웹훅
- 환불/부분환불
- 위치 거부/허용
- KPGA/KLPGA 검증 상태
- 저사양/큰 글씨/간편모드
