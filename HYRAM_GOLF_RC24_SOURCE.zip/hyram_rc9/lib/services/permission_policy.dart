
enum HyramPermission { location, notifications, health, camera }

class PermissionDecision {
  final bool coreAppAvailable;
  final String fallback;
  const PermissionDecision(this.coreAppAvailable, this.fallback);
}

class PermissionPolicy {
  // Permissions are requested only when the user invokes the related feature.
  static const deniedFallback = <HyramPermission, PermissionDecision>{
    HyramPermission.location: PermissionDecision(true, '지역을 직접 선택해 계속 이용'),
    HyramPermission.notifications: PermissionDecision(true, '앱 내 예약/알림함으로 확인'),
    HyramPermission.health: PermissionDecision(true, '건강 연동 없이 핵심 기능 이용'),
    HyramPermission.camera: PermissionDecision(true, '갤러리 선택 또는 직접 입력'),
  };
}
