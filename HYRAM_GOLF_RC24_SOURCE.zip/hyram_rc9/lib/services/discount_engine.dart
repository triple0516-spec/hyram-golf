
class DiscountInput {
  final int basePrice;
  final int proRate, tierRate, couponAmount, membershipAmount;
  final bool allowStack;
  const DiscountInput({required this.basePrice,this.proRate=0,this.tierRate=0,this.couponAmount=0,this.membershipAmount=0,this.allowStack=false});
}
class DiscountResult {
  final int finalPrice, saved;
  final List<String> applied;
  const DiscountResult(this.finalPrice,this.saved,this.applied);
}
class DiscountEngine {
  static DiscountResult calculate(DiscountInput i){
    if (i.basePrice < 0 || i.proRate < 0 || i.proRate > 100 ||
        i.tierRate < 0 || i.tierRate > 100 || i.couponAmount < 0 ||
        i.membershipAmount < 0) {
      throw ArgumentError('Discount inputs must have a nonnegative price and valid rates/amounts.');
    }
    final candidates=<MapEntry<String,int>>[
      MapEntry('PRO', (i.basePrice*i.proRate/100).round()),
      MapEntry('HYRAM 등급', (i.basePrice*i.tierRate/100).round()),
      MapEntry('쿠폰', i.couponAmount),
      MapEntry('회원권', i.membershipAmount),
    ]..removeWhere((e)=>e.value<=0);
    if(candidates.isEmpty)return DiscountResult(i.basePrice,0,const[]);
    int saved; List<String> applied;
    if(i.allowStack){
      saved=candidates.fold(0,(s,e)=>s+e.value); applied=candidates.map((e)=>e.key).toList();
    }else{
      candidates.sort((a,b)=>b.value.compareTo(a.value));
      saved=candidates.first.value; applied=[candidates.first.key];
    }
    saved=saved.clamp(0,i.basePrice).toInt();
    return DiscountResult(i.basePrice-saved,saved,applied);
  }
}
