import 'package:flutter/foundation.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:geolocator/geolocator.dart';
import '../models/app_models.dart';
import '../core/app_environment.dart';

enum AdapterMode { sandbox, productionLocked }

abstract class AuthProviderAdapter {
  String get providerName;
  Future<MemberProfile?> signIn({AdapterMode? mode});
}

class _SandboxAuth {
  static MemberProfile member(String provider) => MemberProfile(
    id: '${provider.toLowerCase()}-sandbox-user',
    name: 'HYRAM MEMBER',
    role: MemberRole.member,
    provider: provider,
  );
}

class GoogleAuthAdapter implements AuthProviderAdapter {
  @override String get providerName => 'Google';
  @override Future<MemberProfile?> signIn({AdapterMode? mode}) async {
    mode ??= HyramEnvironment.isInternal ? AdapterMode.sandbox : AdapterMode.productionLocked;
    if (!HyramEnvironment.isInternal || mode == AdapterMode.productionLocked) {
      throw StateError('Google 운영 자격증명과 서버 토큰 검증이 필요합니다.');
    }
    return _SandboxAuth.member(providerName);
  }
}

class AppleAuthAdapter implements AuthProviderAdapter {
  @override String get providerName => 'Apple';
  @override Future<MemberProfile?> signIn({AdapterMode? mode}) async {
    mode ??= HyramEnvironment.isInternal ? AdapterMode.sandbox : AdapterMode.productionLocked;
    if (!HyramEnvironment.isInternal || mode == AdapterMode.productionLocked) {
      throw StateError('Apple 운영 자격증명과 서버 토큰 검증이 필요합니다.');
    }
    return _SandboxAuth.member(providerName);
  }
}

class KakaoAuthAdapter implements AuthProviderAdapter {
  @override String get providerName => 'Kakao';
  @override Future<MemberProfile?> signIn({AdapterMode? mode}) async {
    mode ??= HyramEnvironment.isInternal ? AdapterMode.sandbox : AdapterMode.productionLocked;
    if (!HyramEnvironment.isInternal || mode == AdapterMode.productionLocked) {
      throw StateError('Kakao 운영 자격증명과 서버 토큰 검증이 필요합니다.');
    }
    return _SandboxAuth.member(providerName);
  }
}

class NaverAuthAdapter implements AuthProviderAdapter {
  @override String get providerName => 'Naver';
  @override Future<MemberProfile?> signIn({AdapterMode? mode}) async {
    mode ??= HyramEnvironment.isInternal ? AdapterMode.sandbox : AdapterMode.productionLocked;
    if (!HyramEnvironment.isInternal || mode == AdapterMode.productionLocked) {
      throw StateError('Naver 운영 자격증명과 서버 토큰 검증이 필요합니다.');
    }
    return _SandboxAuth.member(providerName);
  }
}

class LineAuthAdapter implements AuthProviderAdapter {
  @override String get providerName => 'LINE';
  @override Future<MemberProfile?> signIn({AdapterMode? mode}) async {
    mode ??= HyramEnvironment.isInternal ? AdapterMode.sandbox : AdapterMode.productionLocked;
    if (!HyramEnvironment.isInternal || mode == AdapterMode.productionLocked) {
      throw StateError('LINE Channel 자격증명과 서버 토큰 검증이 필요합니다.');
    }
    return _SandboxAuth.member(providerName);
  }
}

class PaymentAdapter {
  Future<bool> pay({
    required String provider,
    required int amount,
    required String orderId,
    AdapterMode? mode,
  }) async {
    mode ??= HyramEnvironment.isInternal ? AdapterMode.sandbox : AdapterMode.productionLocked;
    if (!HyramEnvironment.isInternal || mode == AdapterMode.productionLocked) {
      throw StateError('운영 결제는 PG/가맹점 승인과 서버 결제 검증 후 활성화됩니다.');
    }
    debugPrint('SANDBOX PAYMENT: $provider / $amount / $orderId');
    await Future<void>.delayed(const Duration(milliseconds: 350));
    return true;
  }
}

class PaymentMethodCatalog {
  static const methods = ['Samsung Pay','신용·체크카드','카카오페이','네이버페이','토스페이'];
}

class LocationService {
  Future<bool> requestConsent() async {
    if (!await Geolocator.isLocationServiceEnabled()) return false;
    var permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }
    return permission == LocationPermission.whileInUse ||
        permission == LocationPermission.always;
  }
}

class HealthService {
  Future<Map<String,dynamic>> summary() async =>
      {'connected': false, 'source': defaultTargetPlatform == TargetPlatform.iOS ? 'HealthKit' : 'Health Connect', 'message': '선택 연결'};
}

class EmergencyService {
  Future<void> triggerSOS() async => debugPrint('SANDBOX SOS requested');
}

class SocialService {
  Future<void> openKakao() async => debugPrint('Kakao share sandbox');
  Future<void> openInstagram() async => debugPrint('Instagram share sandbox');
  Future<void> openFacebook() async => debugPrint('Facebook share sandbox');
}

class GrokService {
  Future<String> scoreFeedback({required int score, required int par}) async {
    final diff = score - par;
    if (diff <= 0) return '오늘 스코어 $score. 퍼팅과 세컨드 샷 흐름이 좋았어요.';
    if (diff <= 5) return '오늘 $score타. 다음 라운드는 세컨드 샷 정확도부터 점검해 볼게요.';
    return '오늘은 $score타. 다음 연습에서는 티샷 이후 두 번째 샷의 반복성을 먼저 보죠.';
  }
  Future<String> nasmoFeedback({required String swingNote}) async =>
      '분석 데이터가 연결되면 $swingNote 항목부터 확인합니다.';
  Future<String> improvementPlan() async =>
      '어드레스 20회 → 하프스윙 30회 → 7번 아이언 20회 → 드라이버 10회';
  Future<String> ask(String prompt) async => '연결된 실제 데이터 기준으로 답변할 준비가 되어 있어요.';
}

class AutoScoreService {
  Future<GolfRound?> importAfterRound() async => null;
}

class BookingService {
  Future<bool> reserveGolfCourse(String course) async => false;
  Future<bool> reserveScreen(String venue) async => false;
  Future<bool> reserveBay(String venue) async => false;
}

class ParkingService {
  Future<Map<String,dynamic>> status() async => {
    'connected': false,
    'available': null,
    'total': null,
    'registeredVehicle': false,
  };
}

class DataRetentionService {
  // Retention is category/purpose/legal-obligation based in production.
  // A single client-side purge period is intentionally not implemented.
}

class AdminMonitorService {
  Future<Map<String,dynamic>> dashboard() async => {
    'members': 0, 'roundsToday': 0, 'bookingsToday': 0, 'paymentsToday': 0,
    'activeIntegrations': 0, 'alerts': 0, 'sandbox': true,
  };
}

class ExternalAppLauncher {
  Future<bool> open(String url) async {
    final uri=Uri.parse(url);
    return launchUrl(uri, mode:LaunchMode.externalApplication);
  }
}
