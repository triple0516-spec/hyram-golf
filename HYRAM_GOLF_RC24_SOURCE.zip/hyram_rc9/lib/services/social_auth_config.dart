
enum SocialProvider { kakao, naver, line, google }

class SocialAuthConfig {
  static const providers = <SocialProvider>[
    SocialProvider.kakao,
    SocialProvider.naver,
    SocialProvider.line,
    SocialProvider.google,
  ];

  static String label(SocialProvider p) => switch (p) {
    SocialProvider.kakao => '카카오로 시작하기',
    SocialProvider.naver => '네이버로 시작하기',
    SocialProvider.line => 'LINE으로 시작하기',
    SocialProvider.google => 'Google로 시작하기',
  };
}

// Production rule:
// 1) App receives provider authorization code/token.
// 2) Backend verifies it with the provider.
// 3) Backend creates/links HYRAM account and returns HYRAM session tokens.
// Never trust profile fields sent only by the client.
