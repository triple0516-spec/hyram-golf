
enum PayMethod { card, samsungPay, kakaoPay, naverPay, tossPay }

class PaymentQuote {
  final String quoteId;
  final int basePrice, discount, finalPrice;
  final String currency;
  const PaymentQuote({
    required this.quoteId,
    required this.basePrice,
    required this.discount,
    required this.finalPrice,
    this.currency='KRW',
  });
}

class PaymentMethodInfo {
  final PayMethod method;
  final String label;
  final bool enabled;
  final String? note;
  const PaymentMethodInfo(this.method,this.label,{this.enabled=true,this.note});
}

class PaymentCatalog {
  static const methods = <PaymentMethodInfo>[
    PaymentMethodInfo(PayMethod.samsungPay,'Samsung Pay', note:'지원 기기/환경에서 사용'),
    PaymentMethodInfo(PayMethod.card,'신용·체크카드'),
    PaymentMethodInfo(PayMethod.kakaoPay,'카카오페이'),
    PaymentMethodInfo(PayMethod.naverPay,'네이버페이'),
    PaymentMethodInfo(PayMethod.tossPay,'토스페이'),
  ];
}

// IMPORTANT:
// The client displays a server-issued quote.
// The backend must revalidate availability, eligibility and amount,
// create the order, confirm payment, verify provider webhook signatures,
// and only then finalize the booking.
