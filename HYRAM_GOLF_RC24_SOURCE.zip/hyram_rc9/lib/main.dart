import 'package:flutter/material.dart';
import 'theme/app_theme.dart';
import 'screens/auth_screen.dart';
import 'screens/signup_screen.dart';
import 'screens/main_shell.dart';
import 'screens/admin/admin_screen.dart';
import 'screens/payment/commercial_checkout_screen.dart';
import 'core/app_environment.dart';

void main()=>runApp(const HyramGolfApp());

class HyramGolfApp extends StatelessWidget{
  const HyramGolfApp({super.key});
  @override Widget build(BuildContext context)=>MaterialApp(
    debugShowCheckedModeBanner:false,
    title:HyramEnvironment.isInternal?'HYRAM GOLF INTERNAL':'HYRAM GOLF',
    theme:hyramTheme(),
    home:const AuthScreen(),
    routes:{
      '/signup':(_)=>const SignupScreen(),
      '/app':(_)=>const MainShell(),
      '/admin':(_)=>HyramEnvironment.isInternal ? const AdminScreen() : const AuthScreen(),
      '/checkout':(_)=>const CommercialCheckoutScreen(),
    },
  );
}
