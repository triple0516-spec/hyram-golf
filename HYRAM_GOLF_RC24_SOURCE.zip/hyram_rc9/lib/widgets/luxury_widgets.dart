import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class GoldLine extends StatelessWidget {
  const GoldLine({super.key});
  @override
  Widget build(BuildContext context) => Container(height: 1, color: HyramColors.gold.withValues(alpha: .35));
}

class LuxuryCard extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  final VoidCallback? onTap;
  const LuxuryCard({super.key, required this.child, this.padding = const EdgeInsets.all(18), this.onTap});
  @override
  Widget build(BuildContext context) {
    final card = Container(
      padding: padding,
      decoration: BoxDecoration(
        color: HyramColors.panel,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: HyramColors.gold.withValues(alpha: .14)),
        boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: .35), blurRadius: 22, offset: const Offset(0, 12))],
      ),
      child: child,
    );
    return onTap == null ? card : InkWell(onTap: onTap, borderRadius: BorderRadius.circular(24), child: card);
  }
}

class BrandMark extends StatelessWidget {
  final double size;
  const BrandMark({super.key, this.size = 44});
  @override
  Widget build(BuildContext context) => Container(
    width: size, height: size,
    decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: HyramColors.gold, width: 1.3)),
    alignment: Alignment.center,
    child: Text('HY\nRAM', textAlign: TextAlign.center, style: TextStyle(color: HyramColors.champagne, fontSize: size * .2, height: .85, letterSpacing: 1.2, fontWeight: FontWeight.w600)),
  );
}

class SectionTitle extends StatelessWidget {
  final String title;
  final String? action;
  final VoidCallback? onAction;
  const SectionTitle(this.title, {super.key, this.action, this.onAction});
  @override
  Widget build(BuildContext context) => Row(children: [
    Expanded(child: Text(title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700, color: HyramColors.ivory))),
    if (action != null) TextButton(onPressed: onAction, child: Text(action!, style: const TextStyle(color: HyramColors.gold))),
  ]);
}
