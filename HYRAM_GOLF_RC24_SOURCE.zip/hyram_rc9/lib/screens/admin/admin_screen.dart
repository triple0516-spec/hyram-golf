import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';
import '../../widgets/luxury_widgets.dart';

class AdminScreen extends StatefulWidget { const AdminScreen({super.key}); @override State<AdminScreen> createState()=>_AdminScreenState(); }
class _AdminScreenState extends State<AdminScreen>{
  bool proDiscount=true, bookingFee=true, premiumMembership=true, promotionRevenue=false;
  double screenFee=5, rangeFee=5, courseFee=4, proScreenDiscount=10, proRangeDiscount=15;
  @override Widget build(BuildContext context)=>Scaffold(body:SafeArea(child:ListView(padding:const EdgeInsets.fromLTRB(20,18,20,30),children:[
    Row(children:[const BrandMark(size:52),const SizedBox(width:12),const Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('HYRAM ADMIN',style:TextStyle(fontSize:24,fontWeight:FontWeight.w700)),Text('대표자 전용 · 운영 & 수익 센터',style:TextStyle(color:HyramColors.muted))])),IconButton(onPressed:()=>ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('관리자 설정은 운영 서버 연결 후 활성화됩니다.'))),icon:const Icon(Icons.settings_outlined))]),
    const SizedBox(height:16),LuxuryCard(child:const Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('SUPER ADMIN',style:TextStyle(color:HyramColors.gold,letterSpacing:2,fontSize:11)),SizedBox(height:8),Text('박형규 · 김하람',style:TextStyle(fontSize:23,fontWeight:FontWeight.w700)),SizedBox(height:4),Text('회원 · 프로 인증 · 예약 · 결제 · 정산 · 제휴 · 서비스 상태를 통합 관리합니다.',style:TextStyle(color:HyramColors.muted,height:1.4))])),
    const SizedBox(height:16),const SectionTitle('REVENUE CENTER'),const SizedBox(height:8),
    GridView.count(shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),crossAxisCount:2,crossAxisSpacing:10,mainAxisSpacing:10,childAspectRatio:1.65,children:[_metric('오늘 거래액','연결 전'),_metric('HYRAM 수익','연결 전'),_metric('환불','연결 전'),_metric('정산 예정','연결 전'),_metric('프로 할인','연결 전'),_metric('결제 성공률','측정 전')]),
    const SizedBox(height:8),const Text('실거래 서버 연결 전에는 금액·성공률을 표시하지 않습니다.',style:TextStyle(color:HyramColors.muted,fontSize:10)),const SizedBox(height:12),_row('매출 · 정산 상세','PG 수수료 · 플랫폼 수익 · 제휴처 정산',Icons.account_balance_wallet_outlined),_row('거래/환불 관리','결제 승인 · 취소 · 환불 · 실패 사유',Icons.receipt_long_outlined),
    const SizedBox(height:16),const SectionTitle('수익 모델 설정'),const SizedBox(height:8),
    _toggle('예약 중개수수료','골프장 · 스크린 · 연습장 예약',bookingFee,(v)=>setState(()=>bookingFee=v)),
    _toggle('프리미엄 멤버십','유료 멤버십 상품 연결',premiumMembership,(v)=>setState(()=>premiumMembership=v)),
    _toggle('프로 인증 할인','승인된 프로 회원 자동 할인',proDiscount,(v)=>setState(()=>proDiscount=v)),
    _toggle('프로모션/광고','제휴 프로모션 수익 — 기본 OFF',promotionRevenue,(v)=>setState(()=>promotionRevenue=v)),
    const SizedBox(height:10),LuxuryCard(child:Column(children:[_rate('스크린 중개 수수료',screenFee,(v)=>setState(()=>screenFee=v)),_rate('연습장 중개 수수료',rangeFee,(v)=>setState(()=>rangeFee=v)),_rate('골프장 중개 수수료',courseFee,(v)=>setState(()=>courseFee=v)),const Divider(color:HyramColors.panel2),_rate('프로 스크린 할인',proScreenDiscount,(v)=>setState(()=>proScreenDiscount=v)),_rate('프로 연습장 할인',proRangeDiscount,(v)=>setState(()=>proRangeDiscount=v))])),
    const SizedBox(height:16),const SectionTitle('운영 센터'),const SizedBox(height:8),
    const SizedBox(height:12),LuxuryCard(child:const Text('운영판에서는 대표자 권한을 서버에서 검증합니다. 카드 원문·비밀번호·본인인증 원문은 관리자에게 표시하지 않으며, 민감정보 접근과 정산 변경은 감사로그를 남기도록 설계합니다.',style:TextStyle(color:HyramColors.muted,fontSize:11,height:1.45)))
  ])));
  Widget _metric(String a,String d)=>LuxuryCard(child:Column(crossAxisAlignment:CrossAxisAlignment.start,mainAxisAlignment:MainAxisAlignment.center,children:[Text(a,style:const TextStyle(color:HyramColors.muted,fontSize:11)),const SizedBox(height:4),Text(d,style:const TextStyle(fontSize:18,fontWeight:FontWeight.w700,color:HyramColors.champagne))]));
  Widget _row(String a,String b,IconData i)=>LuxuryCard(padding:const EdgeInsets.symmetric(horizontal:12,vertical:4),child:ListTile(contentPadding:EdgeInsets.zero,leading:Icon(i,color:HyramColors.gold),title:Text(a),subtitle:Text(b,style:const TextStyle(color:HyramColors.muted,fontSize:10)),trailing:const Icon(Icons.chevron_right,color:HyramColors.muted)));
  Widget _toggle(String a,String b,bool v,ValueChanged<bool> f)=>LuxuryCard(padding:const EdgeInsets.symmetric(horizontal:12,vertical:3),child:SwitchListTile(contentPadding:EdgeInsets.zero,title:Text(a),subtitle:Text(b,style:const TextStyle(color:HyramColors.muted,fontSize:10)),value:v,onChanged:f));
  Widget _rate(String a,double v,ValueChanged<double> f)=>Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Row(children:[Expanded(child:Text(a)),Text('${v.toStringAsFixed(0)}%',style:const TextStyle(color:HyramColors.gold,fontWeight:FontWeight.w700))]),Slider(value:v,min:0,max:30,divisions:30,label:'${v.toStringAsFixed(0)}%',onChanged:f)]);
}
