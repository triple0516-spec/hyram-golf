import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../widgets/luxury_widgets.dart';
import '../services/integration_services.dart';
import '../core/app_environment.dart';
import 'round_screen.dart';
import 'ai_screen.dart';
import 'pro/pro_license_screen.dart';

class HomeScreen extends StatefulWidget {
  final ValueChanged<int>? onNavigate;
  const HomeScreen({super.key,this.onNavigate});
  @override State<HomeScreen> createState()=>_HomeScreenState();
}
class _HomeScreenState extends State<HomeScreen>{
  bool location=false; Map<String,dynamic> parking={};
  @override void initState(){super.initState();ParkingService().status().then((v){if(mounted)setState(()=>parking=v);});}
  void toast(String s)=>ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(s)));
  void push(Widget page)=>Navigator.of(context).push(MaterialPageRoute(builder:(_)=>page));
  @override Widget build(BuildContext context)=>SafeArea(child:ListView(padding:const EdgeInsets.fromLTRB(20,18,20,30),children:[
    Row(children:[const BrandMark(size:48),const SizedBox(width:12),const Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('좋은 하루예요.',style:TextStyle(fontSize:20,fontWeight:FontWeight.w700)),Text('오늘도 필요한 것만 편하게 준비할게요.',style:TextStyle(color:HyramColors.muted,fontSize:11))])),IconButton(tooltip:'알림',onPressed:()=>toast('새로운 중요 알림이 없습니다.'),icon:const Icon(Icons.notifications_none))]),
    const SizedBox(height:16),LuxuryCard(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Row(children:[const Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(HyramEnvironment.isInternal?'HYRAM QA MEMBER':'로그인 연동 전',style:TextStyle(color:HyramColors.gold,fontSize:11,letterSpacing:2)),SizedBox(height:6),Text(HyramEnvironment.isInternal?'SILVER MEMBER':'회원 정보 없음',style:TextStyle(fontSize:24,fontWeight:FontWeight.w700))])),Container(padding:const EdgeInsets.symmetric(horizontal:12,vertical:7),decoration:BoxDecoration(color:HyramColors.panel2,borderRadius:BorderRadius.circular(30)),child:const Row(mainAxisSize:MainAxisSize.min,children:[Icon(Icons.circle,size:8,color:Colors.greenAccent),SizedBox(width:6),Text(HyramEnvironment.isInternal?'QA':'연결 전',style:TextStyle(fontSize:12,fontWeight:FontWeight.w700))]))]),
      const SizedBox(height:14),const Text('혜택은 예약처 연동 후 확인할 수 있어요.',style:TextStyle(fontWeight:FontWeight.w700)),const SizedBox(height:4),const Text('예약할 때 적용 가능한 혜택을 자동으로 비교해 드려요.',style:TextStyle(color:HyramColors.muted,fontSize:11)),
    ])),
    const SizedBox(height:18),const SectionTitle('지금 필요한 것'),const SizedBox(height:10),
    Row(children:[Expanded(child:_action('필드','티타임 찾기',Icons.flag_outlined,()=>widget.onNavigate?.call(1))),const SizedBox(width:8),Expanded(child:_action('스크린','가까운 곳',Icons.sports_esports_outlined,()=>widget.onNavigate?.call(1))),const SizedBox(width:8),Expanded(child:_action('타석','빈 타석',Icons.golf_course_outlined,()=>widget.onNavigate?.call(1))),const SizedBox(width:8),Expanded(child:_action('스코어','기록 보기',Icons.scoreboard_outlined,()=>push(const RoundScreen())))]),
    const SizedBox(height:18),LuxuryCard(onTap:()=>widget.onNavigate?.call(1),child:const Row(children:[CircleAvatar(backgroundColor:HyramColors.panel2,child:Icon(Icons.calendar_month,color:HyramColors.gold)),SizedBox(width:12),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('다음 예약',style:TextStyle(color:HyramColors.muted,fontSize:11)),SizedBox(height:4),Text('예약을 한곳에서 확인해 보세요.',style:TextStyle(fontWeight:FontWeight.w700))])),Icon(Icons.chevron_right)])),
    const SizedBox(height:12),LuxuryCard(onTap:()=>widget.onNavigate?.call(2),child:const Row(children:[Icon(Icons.track_changes,color:HyramColors.gold),SizedBox(width:12),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('MY DRIVING RANGE',style:TextStyle(fontWeight:FontWeight.w700)),SizedBox(height:4),Text('오늘의 연습 · MY CLUB · 스윙 기록',style:TextStyle(color:HyramColors.muted,fontSize:11))])),Icon(Icons.chevron_right)])),
    const SizedBox(height:12),LuxuryCard(onTap:()=>push(const AiScreen()),child:const Row(children:[Icon(Icons.auto_awesome,color:HyramColors.gold),SizedBox(width:12),Expanded(child:Text('GROK GOLF · 골프 질문하기',style:TextStyle(fontWeight:FontWeight.w700))),Icon(Icons.chevron_right)])),
    const SizedBox(height:12),LuxuryCard(onTap:()=>push(const ProLicenseScreen()),child:const Row(children:[Icon(Icons.workspace_premium_outlined,color:HyramColors.gold),SizedBox(width:12),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('프로 라이선스',style:TextStyle(fontWeight:FontWeight.w700)),SizedBox(height:4),Text('KPGA · KLPGA 라이선스 등록 및 확인',style:TextStyle(color:HyramColors.muted,fontSize:11))])),Icon(Icons.chevron_right)])),
    const SizedBox(height:12),LuxuryCard(child:Row(children:[const Icon(Icons.location_on_outlined,color:HyramColors.gold),const SizedBox(width:10),const Expanded(child:Text('내 주변을 더 정확하게\n위치는 필요한 순간에만 사용해요.',style:TextStyle(height:1.45))),Switch(key:const Key('location_permission_switch'),value:location,onChanged:(v)async{
      if(!v){if(mounted)setState(()=>location=false);return;}
      final granted=await LocationService().requestConsent();
      if(!mounted)return;
      setState(()=>location=granted);
      if(!granted)toast('위치 권한 없이도 이용할 수 있어요. BOOKING에서 지역을 직접 선택해 주세요.');
    })])),
  ]));
  Widget _action(String a,String b,IconData i,VoidCallback f)=>LuxuryCard(padding:const EdgeInsets.symmetric(vertical:14,horizontal:6),onTap:f,child:Column(children:[Icon(i,color:HyramColors.gold,size:22),const SizedBox(height:7),Text(a,style:const TextStyle(fontWeight:FontWeight.w700)),Text(b,textAlign:TextAlign.center,style:const TextStyle(color:HyramColors.muted,fontSize:9))]));
}
