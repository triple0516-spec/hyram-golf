import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../widgets/luxury_widgets.dart';
import '../core/app_environment.dart';

class SignupScreen extends StatefulWidget {
  const SignupScreen({super.key});
  @override State<SignupScreen> createState()=>_SignupScreenState();
}
class _SignupScreenState extends State<SignupScreen>{
  int step=0;
  bool phoneVerified=false, terms=false;
  final name=TextEditingController(), phone=TextEditingController(), email=TextEditingController(), pass=TextEditingController();
  final code=TextEditingController();

  void next(){
    if(!HyramEnvironment.isInternal){msg('운영 회원가입은 본인인증 및 계정 서버 연결 후 사용할 수 있어요.');return;}
    if(step==0 && !terms){msg('필수 약관에 동의해 주세요.');return;}
    if(step==1 && !phoneVerified){msg('휴대폰 본인인증을 완료해 주세요.');return;}
    if(step==2 && (name.text.trim().isEmpty || email.text.trim().isEmpty || pass.text.length<8)){
      msg('이름·이메일·8자리 이상 비밀번호를 입력해 주세요.');return;
    }
    if(step<3){setState(()=>step++);}
    else{
      msg('HYRAM QA 회원가입이 완료되었습니다.');
      Navigator.pushNamedAndRemoveUntil(context,'/app',(r)=>false);
    }
  }
  void msg(String s)=>ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(s)));

  @override void dispose(){
    name.dispose();phone.dispose();email.dispose();pass.dispose();code.dispose();super.dispose();
  }

  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('HYRAM 회원가입')),
    body:SafeArea(child:ListView(padding:const EdgeInsets.all(20),children:[
      Text('STEP ${step+1} / 4',style:const TextStyle(color:HyramColors.champagne,letterSpacing:2)),
      const SizedBox(height:8),
      Text(['이용 약관','휴대폰 본인인증','회원 정보','나에게 맞게 준비하기'][step],
        style:const TextStyle(fontSize:24,fontWeight:FontWeight.w600)),
      const SizedBox(height:18),LuxuryCard(child:_content()),const SizedBox(height:14),
      SizedBox(height:56,child:FilledButton(onPressed:HyramEnvironment.isInternal?next:null,child:Text(step==3?'가입하고 HYRAM 시작하기':'계속'))),
    ])));

  Widget _content(){
    if(step==0)return Column(children:[
      CheckboxListTile(value:terms,onChanged:(v)=>setState(()=>terms=v??false),title:const Text('필수 약관 및 개인정보 처리 동의')),
      const ListTile(title:Text('개인정보 보관 정책'),subtitle:Text('운영 출시 전 데이터 종류별 보존기간과 법정 보존의무를 최종 반영합니다.')),
    ]);
    if(step==1)return Column(children:[
      TextField(controller:phone,keyboardType:TextInputType.phone,decoration:const InputDecoration(labelText:'휴대폰 번호',hintText:'01012345678')),
      const SizedBox(height:10),
      OutlinedButton(onPressed:(){
        if(phone.text.length<10){msg('휴대폰 번호를 확인해 주세요.');return;}
        if(HyramEnvironment.isInternal){msg('QA 인증번호: 123456');}else{msg('운영 본인인증 서버 연결 전입니다.');}
      },child:const Text('인증번호 받기')),
      const SizedBox(height:10),
      TextField(controller:code,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'인증번호')),
      const SizedBox(height:10),
      SizedBox(width:double.infinity,child:FilledButton(onPressed:(){
        if(HyramEnvironment.isInternal && code.text=='123456'){setState(()=>phoneVerified=true);msg('본인인증 QA가 완료되었습니다.');}
        else{msg(HyramEnvironment.isInternal?'QA 인증번호를 확인해 주세요.':'운영 본인인증 서버 연결 전입니다.');}
      },child:Text(phoneVerified?'✓ 본인인증 완료':'본인인증 확인'))),
      const SizedBox(height:8),
      const Text('운영판에서는 본인확인기관의 서버 검증 결과로 대체합니다.',style:TextStyle(color:HyramColors.muted,fontSize:11)),
    ]);
    if(step==2)return Column(children:[
      TextField(controller:name,decoration:const InputDecoration(labelText:'이름')),
      const SizedBox(height:10),
      TextField(controller:email,keyboardType:TextInputType.emailAddress,decoration:const InputDecoration(labelText:'이메일')),
      const SizedBox(height:10),
      TextField(controller:pass,obscureText:true,decoration:const InputDecoration(labelText:'비밀번호 (8자리 이상)')),
    ]);
    return const Column(children:[
      ListTile(
        leading:Icon(Icons.workspace_premium_outlined),
        title:Text('SILVER MEMBER로 시작'),
        subtitle:Text('가입 후 KPGA·KLPGA 라이선스를 등록하면 검증 완료 후 PRO 혜택이 열립니다.'),
      ),
      ListTile(
        leading:Icon(Icons.favorite_border),
        title:Text('연결하지 않아도 괜찮아요'),
        subtitle:Text('위치·건강·외부 서비스는 필요한 순간에 선택해서 연결할 수 있어요.'),
      ),
    ]);
  }
}
