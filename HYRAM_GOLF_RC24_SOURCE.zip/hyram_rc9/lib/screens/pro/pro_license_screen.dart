import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../core/app_environment.dart';

class ProLicenseScreen extends StatefulWidget {
  const ProLicenseScreen({super.key});
  @override State<ProLicenseScreen> createState()=>_S();
}
class _S extends State<ProLicenseScreen>{
  String association='KPGA', type='프로';
  final name=TextEditingController(), no=TextEditingController();
  bool submitted=false;

  Uri get officialSearch => association=='KLPGA'
      ? Uri.parse('https://data.klpga.co.kr/search.jsp')
      : Uri.parse('https://www.kpga.co.kr/tours/player/player/?tourId=13');

  @override void dispose(){ name.dispose(); no.dispose(); super.dispose(); }

  Future<void> openOfficialSearch() async {
    await launchUrl(officialSearch, mode: LaunchMode.externalApplication);
  }

  @override Widget build(BuildContext c)=>Scaffold(
    appBar:AppBar(title:const Text('프로 라이선스 추가')),
    body:ListView(padding:const EdgeInsets.all(20),children:[
      const Text('공식 협회에서 확인하고 등록하세요.',style:TextStyle(fontSize:24,fontWeight:FontWeight.w700)),
      const SizedBox(height:8),
      const Text('성별을 묻지 않습니다. KPGA 또는 KLPGA를 선택해 공식 검색에서 확인한 뒤 라이선스를 등록합니다.'),
      const SizedBox(height:20),
      SegmentedButton<String>(
        segments:const [
          ButtonSegment(value:'KPGA',label:Text('KPGA')),
          ButtonSegment(value:'KLPGA',label:Text('KLPGA')),
        ],
        selected:{association},
        onSelectionChanged:(s)=>setState((){
          association=s.first;
          type=association=='KLPGA'?'정회원':'프로';
        }),
      ),
      const SizedBox(height:14),
      OutlinedButton.icon(
        onPressed:openOfficialSearch,
        icon:const Icon(Icons.open_in_new),
        label:Text('${association} 공식 선수 검색 바로가기'),
      ),
      const SizedBox(height:14),
      TextField(controller:name,decoration:const InputDecoration(labelText:'라이선스 명의자 이름')),
      const SizedBox(height:10),
      DropdownButtonFormField<String>(
        value:type,
        items:(association=='KLPGA'
          ? ['정회원','준회원','티칭회원','기타 확인']
          : ['프로','투어프로'])
          .map((e)=>DropdownMenuItem(value:e,child:Text('$association $e'))).toList(),
        onChanged:(v)=>setState(()=>type=v!),
        decoration:const InputDecoration(labelText:'회원 구분'),
      ),
      const SizedBox(height:10),
      TextField(controller:no,decoration:InputDecoration(labelText:'$association 회원번호')),
      const SizedBox(height:14),
      FilledButton(
        onPressed:(){
          if(name.text.trim().isEmpty||no.text.trim().isEmpty){
            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('이름과 회원번호를 입력해 주세요.')));
            return;
          }
          if (!HyramEnvironment.isInternal) {
            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('운영 검증 접수 서버 연결 전입니다. 요청은 접수되지 않았어요.')));
            return;
          }
          setState(()=>submitted=true);
        },
        child:const Text('라이선스 확인 요청'),
      ),
      if(submitted) const Padding(
        padding:EdgeInsets.only(top:16),
        child:Card(child:ListTile(
          leading:Icon(Icons.verified_user_outlined),
          title:Text('QA 검증 요청 화면입니다'),
          subtitle:Text('TEST에서는 검증 흐름만 확인합니다. 운영판의 자동 검증은 각 협회의 공식 API·제휴 허용 범위에서 연결합니다.'),
        )),
      ),
    ]),
  );
}
