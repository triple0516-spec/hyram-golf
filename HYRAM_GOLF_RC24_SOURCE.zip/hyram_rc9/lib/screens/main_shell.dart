import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import 'home_screen.dart';
import 'booking_screen.dart';
import 'driving_range/my_driving_range_screen.dart';
import 'more_screen.dart';

class MainShell extends StatefulWidget {
  const MainShell({super.key});
  @override State<MainShell> createState()=>_MainShellState();
}
class _MainShellState extends State<MainShell>{
  int index=0;
  late final pages=<Widget>[
    HomeScreen(onNavigate:(i)=>setState(()=>index=i)),
    const BookingScreen(),
    const MyDrivingRangeScreen(),
    const MoreScreen(),
  ];
  @override Widget build(BuildContext context)=>Scaffold(
    body:IndexedStack(index:index,children:pages),
    bottomNavigationBar:NavigationBar(
      backgroundColor:HyramColors.panel,
      indicatorColor:HyramColors.gold.withOpacity(.14),
      selectedIndex:index,
      onDestinationSelected:(i)=>setState(()=>index=i),
      destinations:const[
        NavigationDestination(icon:Icon(Icons.home_outlined),selectedIcon:Icon(Icons.home),label:'HOME'),
        NavigationDestination(icon:Icon(Icons.calendar_month_outlined),selectedIcon:Icon(Icons.calendar_month),label:'BOOKING'),
        NavigationDestination(icon:Icon(Icons.sports_golf_outlined),selectedIcon:Icon(Icons.sports_golf),label:'RANGE'),
        NavigationDestination(icon:Icon(Icons.person_outline),selectedIcon:Icon(Icons.person),label:'MY HYRAM'),
      ],
    ),
  );
}
