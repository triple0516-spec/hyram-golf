import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import '../theme/app_theme.dart';
import '../widgets/luxury_widgets.dart';
import '../services/integration_services.dart';
import '../core/app_environment.dart';
import 'pro/pro_license_screen.dart';
import 'profile/data_center_screen.dart';

class MoreScreen extends StatefulWidget { const MoreScreen({super.key}); @override State<MoreScreen> createState()=>_MoreScreenState(); }
class _MoreScreenState extends State<MoreScreen>{bool health=false,location=false,emergency=false,vehicle=false;
 void _pendingPermission(String name){
   _status(name);
 }
 void _status(String name)=>ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('$name 운영 연동 전 QA 상태입니다. 핵심 기능은 계속 사용할 수 있어요.')));
 @override Widget build(BuildContext context)=>SafeArea(child:ListView(padding:const EdgeInsets.all(20),children:[const Text('MY',style:TextStyle(color:HyramColors.gold,letterSpacing:3,fontSize:11)),const SizedBox(height:6),const Text('내 정보 · 연결 · 차량',style:TextStyle(fontSize:28,fontWeight:FontWeight.w700)),const SizedBox(height:16),LuxuryCard(child:Row(children:[const BrandMark(size:56),const SizedBox(width:12),const Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(HyramEnvironment.isInternal?'HYRAM QA MEMBER':'계정 연동 전',style:TextStyle(fontSize:19,fontWeight:FontWeight.w700)),Text('PRIVATE MEMBER · LIMITED EDITION',style:TextStyle(color:HyramColors.gold,fontSize:10,letterSpacing:1))])),const Icon(Icons.person_outline,color:HyramColors.gold)])),const SizedBox(height:16),const SectionTitle('멤버십 & 프로 인증'),const SizedBox(height:8),_link('프로 라이선스','KPGA · KLPGA 라이선스 등록 · 확인',Icons.workspace_premium_outlined,onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const ProLicenseScreen()))),const SizedBox(height:16),const SectionTitle('내 정보 & 연결'),const SizedBox(height:8),_link('내 정보 연결','직접 등록 · 선택적 자동 연동',Icons.hub_outlined,onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const DataCenterScreen()))),const SizedBox(height:8),_sw('현재 위치 동의','실제 권한 연결 전 · 수동 지역 선택 가능',location,(v)=>_pendingPermission('위치')),_sw('건강 데이터',defaultTargetPlatform == TargetPlatform.iOS ? 'HealthKit 운영 연결 전' : 'Health Connect 운영 연결 전',health,(v)=>_pendingPermission('건강 데이터')),_sw('긴급 서비스','지정 연락처/위치 공유 운영 연결 전',emergency,(v)=>_pendingPermission('긴급 서비스')),_sw('차량 등록','차량 등록 저장소 연결 전',vehicle,(v)=>_pendingPermission('차량 등록')),const SizedBox(height:16),const SectionTitle('SNS · 메신저'),const SizedBox(height:8),_link('카카오톡','공유 기능은 운영 앱 등록 후 활성화',Icons.chat_bubble_outline,onTap:()=>_status('카카오톡')),_link('Instagram','공유 기능은 운영 앱 등록 후 활성화',Icons.camera_alt_outlined,onTap:()=>_status('Instagram')),_link('Facebook','공유 기능은 운영 앱 등록 후 활성화',Icons.public,onTap:()=>_status('Facebook')),_link('LINE','로그인/공유 운영 채널 승인 후 활성화',Icons.message_outlined,onTap:()=>_status('LINE')),const SizedBox(height:16),const SectionTitle('데이터 & 계정'),const SizedBox(height:8),LuxuryCard(child:Column(children:[
 const ListTile(contentPadding:EdgeInsets.zero,title:Text('데이터 보관'),subtitle:Text('데이터 종류·이용 목적·법정 보존의무에 따라 서로 다른 기간을 적용합니다.')),
 const Divider(color:HyramColors.panel2),
 ListTile(onTap:()=>_status('내 데이터 다운로드'),contentPadding:EdgeInsets.zero,title:const Text('내 데이터 다운로드'),subtitle:const Text('운영 계정 API 연결 후 제공',style:TextStyle(color:HyramColors.muted,fontSize:10)),trailing:const Icon(Icons.download_outlined,color:HyramColors.gold)),
 ListTile(onTap:()=>_status('계정 삭제'),contentPadding:EdgeInsets.zero,title:const Text('계정 삭제'),subtitle:const Text('운영 계정 API 연결 후 본인확인과 함께 처리',style:TextStyle(color:HyramColors.muted,fontSize:10)),trailing:const Icon(Icons.delete_outline,color:HyramColors.danger)),
])),const SizedBox(height:10),const Text('QA 화면은 실제 개인정보를 삭제하거나 내보내지 않습니다.',style:TextStyle(color:HyramColors.muted,fontSize:10,height:1.4))]));
 Widget _sw(String a,String b,bool v,ValueChanged<bool> f)=>LuxuryCard(padding:const EdgeInsets.symmetric(horizontal:12,vertical:3),child:SwitchListTile(contentPadding:EdgeInsets.zero,title:Text(a),subtitle:Text(b,style:const TextStyle(color:HyramColors.muted,fontSize:10)),value:v,onChanged:f));
 Widget _link(String a,String b,IconData i,{VoidCallback? onTap})=>LuxuryCard(padding:const EdgeInsets.symmetric(horizontal:12,vertical:3),child:ListTile(onTap:onTap,contentPadding:EdgeInsets.zero,leading:Icon(i,color:HyramColors.gold),title:Text(a),subtitle:Text(b,style:const TextStyle(color:HyramColors.muted,fontSize:10)),trailing:const Icon(Icons.chevron_right,color:HyramColors.muted)));
}
