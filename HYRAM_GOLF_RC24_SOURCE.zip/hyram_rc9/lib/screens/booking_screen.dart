import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../widgets/luxury_widgets.dart';
import '../services/integration_services.dart';
import '../core/app_environment.dart';

class BookingScreen extends StatefulWidget {
  const BookingScreen({super.key});
  @override State<BookingScreen> createState()=>_BookingScreenState();
}

class _BookingScreenState extends State<BookingScreen>{
  int tab=0;

  @override
  Widget build(BuildContext context)=>SafeArea(
    child:ListView(
      padding:const EdgeInsets.all(20),
      children:[
        const Text('CONCIERGE',style:TextStyle(color:HyramColors.gold,letterSpacing:3,fontSize:11)),
        const SizedBox(height:6),
        const Text('부킹 · 타석 · 결제',style:TextStyle(fontSize:28,fontWeight:FontWeight.w700)),
        const SizedBox(height:16),
        Row(children:[
          _switchTab('골프장',0),
          _switchTab('스크린',1),
          _switchTab('타석',2),
        ]),
        const SizedBox(height:14),
        LuxuryCard(child:Column(children:[
          const TextField(decoration:InputDecoration(prefixIcon:Icon(Icons.search),hintText:'골프장 · 지역 · 날짜 검색')),
          const SizedBox(height:12),
          Row(children:[_chip('오늘'),_chip('부산'),_chip('2인'),_chip('3인')]),
        ])),
        const SizedBox(height:18),
        if(!HyramEnvironment.isInternal) const LuxuryCard(child:Text('실시간 예약 공급처 연결 전입니다. 예약 가능 시간과 가격은 아직 표시할 수 없습니다.')),
        if(HyramEnvironment.isInternal && tab==0)...[
          _course('가야 CC','09.27 · 08:10 · 4인','₩180,000'),
          _course('오션힐스 부산','09.28 · 07:40 · 4인','₩220,000'),
        ],
        if(HyramEnvironment.isInternal && tab==1)...[
          _course('골프존 프리미엄 서면','오늘 · 19:30 · 2인','₩24,000'),
          _course('프렌즈스크린 센텀','오늘 · 21:00 · 2인','₩20,000'),
        ],
        if(HyramEnvironment.isInternal && tab==2)...[
          _course('센텀 타석 7번','현재 · 30분','₩8,000'),
          _course('하단 연습장 12번','20:10 · 60분','₩15,000'),
        ],
        const SizedBox(height:18),
        LuxuryCard(child:Column(
          crossAxisAlignment:CrossAxisAlignment.start,
          children:[
            const SectionTitle('간편결제'),
            const SizedBox(height:8),
            ...PaymentMethodCatalog.methods.map((x)=>ListTile(
              contentPadding:EdgeInsets.zero,
              leading:const Icon(Icons.credit_card,color:HyramColors.gold),
              title:Text(x),
              subtitle:const Text('운영 PG/가맹점 승인 후 실제 결제 활성화',style:TextStyle(color:HyramColors.muted,fontSize:10)),
              trailing:const Icon(Icons.chevron_right,color:HyramColors.muted),
            )),
          ],
        )),
        const SizedBox(height:10),
        const Text(
          '카드번호·CVC·계좌 비밀번호는 HYRAM 앱에 저장하지 않고 승인 사업자의 결제 흐름으로 처리합니다.',
          style:TextStyle(color:HyramColors.muted,fontSize:10,height:1.4),
        ),
      ],
    ),
  );

  Widget _switchTab(String t,int i)=>Expanded(
    child:Padding(
      padding:const EdgeInsets.only(right:6),
      child:ChoiceChip(
        label:SizedBox(width:double.infinity,child:Center(child:Text(t))),
        selected:tab==i,
        onSelected:(_)=>setState(()=>tab=i),
      ),
    ),
  );

  Widget _chip(String t)=>Expanded(
    child:Container(
      margin:const EdgeInsets.only(right:5),
      padding:const EdgeInsets.symmetric(vertical:9),
      decoration:BoxDecoration(color:HyramColors.panel2,borderRadius:BorderRadius.circular(12)),
      child:Center(child:Text(t,style:const TextStyle(fontSize:11))),
    ),
  );

  Widget _course(String n,String d,String p)=>Padding(
    padding:const EdgeInsets.only(bottom:10),
    child:LuxuryCard(
      child:Row(children:[
        const Icon(Icons.flag_outlined,color:HyramColors.gold,size:28),
        const SizedBox(width:12),
        Expanded(child:Column(
          crossAxisAlignment:CrossAxisAlignment.start,
          children:[
            Text('[QA 예시] $n',style:const TextStyle(fontWeight:FontWeight.w700)),
            Text(d,style:const TextStyle(color:HyramColors.muted,fontSize:11)),
          ],
        )),
        Column(
          crossAxisAlignment:CrossAxisAlignment.end,
          children:[
            Text(p,style:const TextStyle(color:HyramColors.champagne,fontWeight:FontWeight.w700)),
            TextButton(
              onPressed:()=>Navigator.pushNamed(context,'/checkout'),
              child:const Text('예약 테스트'),
            ),
          ],
        ),
      ]),
    ),
  );
}
