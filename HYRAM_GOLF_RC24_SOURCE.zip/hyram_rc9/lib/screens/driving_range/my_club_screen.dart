import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';
import '../../widgets/luxury_widgets.dart';
import '../../core/app_environment.dart';

class MyClubScreen extends StatelessWidget {
  const MyClubScreen({super.key});
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('MY CLUB')),
    body:SafeArea(child:ListView(padding:const EdgeInsets.all(20),children:[
      const Text('내 클럽을 직접 등록해 주세요.',style:TextStyle(fontSize:23,fontWeight:FontWeight.w700)),
      const SizedBox(height:6),
      const Text('자동 연동 없이도 사용할 수 있고, 연결된 데이터가 있으면 선택적으로 채울 수 있어요.',style:TextStyle(color:HyramColors.muted)),
      const SizedBox(height:18),
      LuxuryCard(child:Column(children:[
        const TextField(decoration:InputDecoration(labelText:'브랜드 · 모델')),
        const SizedBox(height:10),
        const TextField(decoration:InputDecoration(labelText:'클럽 종류')),
        const SizedBox(height:10),
        const TextField(decoration:InputDecoration(labelText:'로프트 / 라이 / 길이')),
        const SizedBox(height:10),
        const TextField(decoration:InputDecoration(labelText:'샤프트 · FLEX · 무게')),
        const SizedBox(height:10),
        const TextField(decoration:InputDecoration(labelText:'평균 Carry / Total')),
        const SizedBox(height:14),
        SizedBox(width:double.infinity,child:FilledButton(
          onPressed:HyramEnvironment.isInternal ? ()=>ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content:Text('입력 화면 QA입니다. 클럽 정보는 저장되지 않았어요.'))) : null,
          child:Text(HyramEnvironment.isInternal ? '입력 화면 테스트' : '클럽 저장 연동 전'),
        )),
      ])),
    ])));
}
