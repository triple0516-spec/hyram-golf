import 'package:flutter/material.dart';
import '../../theme/app_theme.dart';
import '../../widgets/luxury_widgets.dart';
import '../round_screen.dart';
import '../booking_screen.dart';
import 'my_club_screen.dart';

class MyDrivingRangeScreen extends StatelessWidget{
  const MyDrivingRangeScreen({super.key});
  void _msg(BuildContext c,String s)=>ScaffoldMessenger.of(c).showSnackBar(SnackBar(content:Text(s)));
  @override Widget build(BuildContext c)=>SafeArea(child:ListView(padding:const EdgeInsets.all(20),children:[
    const Text('MY DRIVING RANGE',style:TextStyle(color:HyramColors.gold,letterSpacing:2,fontSize:11)),
    const SizedBox(height:6),
    const Text('오늘의 연습을 준비했어요.',style:TextStyle(fontSize:26,fontWeight:FontWeight.w700)),
    const SizedBox(height:6),
    const Text('복잡한 기록보다 오늘 필요한 연습부터 보여드려요.',style:TextStyle(color:HyramColors.muted)),
    const SizedBox(height:18),
    LuxuryCard(onTap:()=>_msg(c,'오늘의 연습 QA를 시작했어요.'),child:const ListTile(contentPadding:EdgeInsets.zero,title:Text('오늘의 연습',style:TextStyle(fontWeight:FontWeight.w700)),subtitle:Text('웨지 거리감 20분 · 7번 아이언 방향성 20분 · 드라이버 15분'),trailing:Icon(Icons.play_circle_outline,color:HyramColors.gold))),
    const SizedBox(height:10),
    LuxuryCard(onTap:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>const Scaffold(body:BookingScreen()))),child:const ListTile(contentPadding:EdgeInsets.zero,title:Text('타석 찾기'),subtitle:Text('가까운 연습장 · 빈 타석 · 가격 · 내 혜택'),trailing:Icon(Icons.chevron_right))),
    const SizedBox(height:10),
    LuxuryCard(onTap:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>const MyClubScreen())),child:const ListTile(contentPadding:EdgeInsets.zero,title:Text('MY CLUB'),subtitle:Text('클럽 세팅 · 샤프트 · 거리표 · 변경 이력'),trailing:Icon(Icons.chevron_right))),
    const SizedBox(height:10),
    LuxuryCard(onTap:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>const Scaffold(body:RoundScreen()))),child:const ListTile(contentPadding:EdgeInsets.zero,title:Text('스윙 & 라운드 기록'),subtitle:Text('영상 · 나스모 · 반복 미스 · 최근 라운드'),trailing:Icon(Icons.chevron_right))),
    const SizedBox(height:10),
    LuxuryCard(onTap:()=>_msg(c,'아직 저장된 연습 히스토리가 없어요.'),child:const ListTile(contentPadding:EdgeInsets.zero,title:Text('연습 히스토리'),subtitle:Text('연습량 · 클럽별 기록 · 지난 과제'),trailing:Icon(Icons.chevron_right))),
  ]));
}
