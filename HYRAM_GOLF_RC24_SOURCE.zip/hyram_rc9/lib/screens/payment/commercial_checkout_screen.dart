
import 'package:flutter/material.dart';
import '../../services/payment_gateway.dart';
import '../../core/app_environment.dart';

class CommercialCheckoutScreen extends StatefulWidget {
  const CommercialCheckoutScreen({super.key});
  @override State<CommercialCheckoutScreen> createState()=>_S();
}
class _S extends State<CommercialCheckoutScreen>{
  PayMethod selected=PayMethod.samsungPay;
  String qaOutcome='SUCCESS';
  final quote=const PaymentQuote(quoteId:'TEST-Q-001',basePrice:200000,discount:40000,finalPrice:160000);

  String won(int n)=>'${n.toString().replaceAllMapped(RegExp(r'(\d)(?=(\d{3})+(?!\d))'),(m)=>'${m[1]},')}원';

  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('결제')),
    body:ListView(padding:const EdgeInsets.all(20),children:[
      const Text('예약·결제 연동 전입니다. 실제 금액과 혜택은 연결 후 확인됩니다.',style:TextStyle(fontSize:20,fontWeight:FontWeight.w700)),
      const SizedBox(height:18),
      if (HyramEnvironment.isInternal) Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(children:[
        _row('기본 금액',won(quote.basePrice)),
        const SizedBox(height:8),_row('적용 혜택','- ${won(quote.discount)}'),
        const Divider(height:26),
        _row('최종 결제금액',won(quote.finalPrice),strong:true),
      ]))),
      const SizedBox(height:20),
      if (HyramEnvironment.isInternal) const Text('결제수단',style:TextStyle(fontSize:17,fontWeight:FontWeight.w700)),
      const SizedBox(height:8),
      if (HyramEnvironment.isInternal) ...PaymentCatalog.methods.map((m)=>RadioListTile<PayMethod>(
        value:m.method,groupValue:selected,onChanged:(v)=>setState(()=>selected=v!),
        title:Text(m.label),subtitle:m.note==null?null:Text(m.note!),
      )),
      const SizedBox(height:10),
      if (HyramEnvironment.isInternal) DropdownButtonFormField<String>(
        value:qaOutcome,
        decoration:const InputDecoration(labelText:'내부 QA 결제 결과'),
        items:const ['SUCCESS','CANCELLED','FAILED','TIMEOUT','PENDING','DUPLICATE']
          .map((x)=>DropdownMenuItem(value:x,child:Text(x))).toList(),
        onChanged:(v)=>setState(()=>qaOutcome=v!),
      ),
      const SizedBox(height:10),
      if (HyramEnvironment.isInternal) CheckboxListTile(value:true,onChanged:null,title:const Text('결제 및 취소·환불 조건을 확인했습니다.')),
      const SizedBox(height:8),
      SizedBox(height:56,child:FilledButton(
        onPressed:HyramEnvironment.isInternal ? ()=>showDialog(context:context,builder:(c)=>AlertDialog(
          title:Text(HyramEnvironment.isInternal ? 'SANDBOX · $qaOutcome' : '결제 연동 전'),
          content:Text(HyramEnvironment.isInternal ? _qaMessage(qaOutcome) : '운영 결제는 가맹점 및 서버 승인 연동 후 사용할 수 있습니다. 실제 결제는 진행되지 않았어요.'),
          actions:[TextButton(onPressed:()=>Navigator.pop(c),child:const Text('확인'))],
        )) : null,
        child:Text(HyramEnvironment.isInternal ? '${won(quote.finalPrice)} 결제 테스트' : '결제 연동 전'),
      )),
    ]),
  );

  String _qaMessage(String state){
    switch(state){
      case 'SUCCESS': return '샌드박스 결제 성공 흐름입니다. 실제 과금은 발생하지 않습니다.';
      case 'CANCELLED': return '사용자가 결제를 취소했습니다. 예약을 확정하지 않습니다.';
      case 'FAILED': return '결제 승인 실패 상태입니다. 재시도 또는 다른 결제수단을 안내합니다.';
      case 'TIMEOUT': return '결제 결과 확인 시간이 초과되었습니다. 성공으로 단정하지 않고 서버 상태를 다시 확인해야 합니다.';
      case 'PENDING': return '결제 처리 중입니다. 최종 승인 웹훅 전에는 예약을 확정하지 않습니다.';
      case 'DUPLICATE': return '중복 요청을 감지했습니다. 동일 주문은 한 번만 처리해야 합니다.';
      default: return '알 수 없는 QA 상태입니다.';
    }
  }

  Widget _row(String a,String b,{bool strong=false})=>Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[
    Text(a,style:TextStyle(fontWeight:strong?FontWeight.w700:FontWeight.w400)),
    Text(b,style:TextStyle(fontSize:strong?20:14,fontWeight:strong?FontWeight.w800:FontWeight.w500)),
  ]);
}
