import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import '../theme/app_theme.dart';
import '../widgets/luxury_widgets.dart';
import '../services/integration_services.dart';
import '../core/app_environment.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});
  @override State<AuthScreen> createState()=>_AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  bool representative=false;
  bool socialBusy=false;
  final email=TextEditingController(text:HyramEnvironment.isInternal?'test@hyram.golf':'');
  final password=TextEditingController(text:HyramEnvironment.isInternal?'12345678':'');

  void login(){
    if(!HyramEnvironment.isInternal){
      _msg('운영 인증 서버 연결 전에는 이메일 로그인을 진행하지 않습니다.');
      return;
    }
    if(email.text.trim().isEmpty || password.text.length<8){
      _msg('이메일과 8자리 이상 비밀번호를 확인해 주세요.');
      return;
    }
    Navigator.pushReplacementNamed(context, (HyramEnvironment.isInternal && representative)?'/admin':'/app');
  }

  Future<void> social(AuthProviderAdapter adapter) async {
    if (socialBusy) return;
    setState(()=>socialBusy=true);
    try {
      final profile=await adapter.signIn();
      if (!mounted) return;
      if (profile == null) {
        _msg('${adapter.providerName} 로그인이 취소되었습니다.');
        return;
      }
      _msg('${adapter.providerName} 샌드박스 로그인 확인 완료');
      Navigator.pushReplacementNamed(context,'/app');
    } catch (_) {
      if(mounted) _msg('로그인을 완료하지 못했어요. 다시 시도해 주세요.');
    } finally {
      if(mounted) setState(()=>socialBusy=false);
    }
  }

  void _msg(String s)=>ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(s)));

  @override void dispose(){
    email.dispose(); password.dispose(); super.dispose();
  }

  @override Widget build(BuildContext context)=>Scaffold(body:SafeArea(child:ListView(
    padding:const EdgeInsets.fromLTRB(24,32,24,20),children:[
      const SizedBox(height:20), const Center(child:BrandMark(size:92)), const SizedBox(height:18),
      const Center(child:Text('HYRAM',style:TextStyle(fontSize:31,letterSpacing:6,fontWeight:FontWeight.w600,color:HyramColors.champagne))),
      const Center(child:Padding(padding:EdgeInsets.only(top:7),child:Text('Golf, personally.',style:TextStyle(fontSize:12,letterSpacing:2,color:HyramColors.muted)))),
      const SizedBox(height:34),
      LuxuryCard(child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
        const Text('좋은 라운드의 시작을 준비해 드릴게요.',style:TextStyle(fontSize:17,fontWeight:FontWeight.w600)),
        const SizedBox(height:16),
        TextField(controller:email,decoration:const InputDecoration(prefixIcon:Icon(Icons.person_outline),labelText:'이메일 또는 휴대폰 번호')),
        const SizedBox(height:10),
        TextField(controller:password,obscureText:true,decoration:const InputDecoration(prefixIcon:Icon(Icons.lock_outline),labelText:'비밀번호')),
        const SizedBox(height:14),
        SizedBox(height:54,child:FilledButton(onPressed:login,child:const Text('로그인'))),
        const SizedBox(height:8),
        SizedBox(height:50,child:OutlinedButton(onPressed:()=>Navigator.pushNamed(context,'/signup'),child:const Text('처음이신가요? 회원가입'))),
      ])),
      const SizedBox(height:14),
      if(HyramEnvironment.isInternal) LuxuryCard(padding:const EdgeInsets.symmetric(horizontal:14,vertical:8),child:SwitchListTile(
        contentPadding:EdgeInsets.zero,title:const Text('대표자 테스트 모드'),
        subtitle:const Text('관리자 화면 QA용',style:TextStyle(color:HyramColors.muted,fontSize:11)),
        value:representative,onChanged:(v)=>setState(()=>representative=v))),
      const SizedBox(height:16),
      Center(child:Text(HyramEnvironment.isInternal?'간편 로그인 · QA SANDBOX':'간편 로그인 · 운영 연결 전',style:TextStyle(color:HyramColors.muted,fontSize:12))),
      const SizedBox(height:8),
      SizedBox(height:50,child:FilledButton(
        onPressed:socialBusy?null:()=>social(KakaoAuthAdapter()),child:const Text('카카오로 시작하기'))),
      const SizedBox(height:8),
      Row(children:[
        Expanded(child:OutlinedButton(onPressed:socialBusy?null:()=>social(NaverAuthAdapter()),child:const Text('네이버'))),
        const SizedBox(width:8),
        Expanded(child:OutlinedButton(onPressed:socialBusy?null:()=>social(LineAuthAdapter()),child:const Text('LINE'))),
        const SizedBox(width:8),
        Expanded(child:OutlinedButton(onPressed:socialBusy?null:()=>social(GoogleAuthAdapter()),child:const Text('Google'))),
      ]),
      if(defaultTargetPlatform == TargetPlatform.iOS) ...[
        const SizedBox(height:8),
        SizedBox(height:50,child:OutlinedButton(onPressed:socialBusy?null:()=>social(AppleAuthAdapter()),child:const Text('Apple로 시작하기'))),
      ],
      const SizedBox(height:12),
      Text(HyramEnvironment.isInternal?'RC9 INTERNAL · 샌드박스 동선 검증용이며 운영 계정 인증은 발생하지 않습니다.':'운영 인증 연동 전 · 실제 계정 인증은 진행되지 않습니다.',textAlign:TextAlign.center,style:TextStyle(color:HyramColors.muted,fontSize:10)),
    ])));
}
