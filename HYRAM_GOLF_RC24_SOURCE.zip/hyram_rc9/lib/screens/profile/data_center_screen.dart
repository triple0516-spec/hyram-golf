
import 'package:flutter/material.dart';
class DataCenterScreen extends StatelessWidget{const DataCenterScreen({super.key});
 @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('내 정보 · 연결')),body:ListView(padding:const EdgeInsets.all(18),children:[
  const Text('내 정보는 내가 결정해요',style:TextStyle(fontSize:24,fontWeight:FontWeight.w700)),
  const SizedBox(height:6),const Text('직접 등록을 기본으로 두고, 원하는 항목만 연결해서 자동으로 채울 수 있습니다.'),
  const SizedBox(height:18),
  const Card(child:ListTile(leading:Icon(Icons.edit_outlined),title:Text('직접 등록'),subtitle:Text('프로필 · 핸디캡 · 클럽 · 회원권 · 차량'),trailing:Text('기본'))),
  const Card(child:ListTile(leading:Icon(Icons.health_and_safety_outlined),title:Text('Health Connect / HealthKit'),subtitle:Text('걸음 · 운동 · 심박 등 사용자가 허용한 항목만'),trailing:Icon(Icons.chevron_right))),
  const Card(child:ListTile(leading:Icon(Icons.sports_golf_outlined),title:Text('골프 서비스 연결'),subtitle:Text('스코어 · 라운드 · 영상은 공식 API/제휴가 가능한 서비스부터'),trailing:Icon(Icons.chevron_right))),
  const Card(child:ListTile(leading:Icon(Icons.location_on_outlined),title:Text('위치'),subtitle:Text('주변 연습장·스크린·골프장을 보여줄 때만 사용'),trailing:Icon(Icons.chevron_right))),
  const SizedBox(height:10),const Text('연결하지 않아도 HYRAM의 핵심 기능은 사용할 수 있습니다.',style:TextStyle(fontSize:12))
 ]));}
