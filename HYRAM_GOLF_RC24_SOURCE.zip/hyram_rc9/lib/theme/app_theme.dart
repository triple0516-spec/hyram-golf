import 'package:flutter/material.dart';

class HyramColors {
  static const black = Color(0xFF090909);
  static const panel = Color(0xFF141414);
  static const panel2 = Color(0xFF1B1B1B);
  static const gold = Color(0xFFD9B36C);
  static const champagne = Color(0xFFF2D7A0);
  static const ivory = Color(0xFFF6F0E5);
  static const muted = Color(0xFF9A968E);
  static const danger = Color(0xFFE85B55);
}

ThemeData hyramTheme() {
  final base = ThemeData.dark(useMaterial3: true);
  return base.copyWith(
    scaffoldBackgroundColor: HyramColors.black,
    colorScheme: const ColorScheme.dark(
      primary: HyramColors.gold,
      secondary: HyramColors.champagne,
      surface: HyramColors.panel,
      error: HyramColors.danger,
    ),
    textTheme: base.textTheme.apply(fontFamily: 'sans'),
    appBarTheme: const AppBarTheme(
      backgroundColor: HyramColors.black,
      foregroundColor: HyramColors.ivory,
      elevation: 0,
      centerTitle: false,
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: HyramColors.panel,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: BorderSide.none,
      ),
    ),
  );
}
