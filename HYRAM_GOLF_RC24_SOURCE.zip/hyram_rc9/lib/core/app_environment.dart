enum AppEnvironment { internal, production }

class HyramEnvironment {
  static const raw = String.fromEnvironment('HYRAM_ENV', defaultValue: 'production');
  static bool get isInternal => raw == 'internal';
  static AppEnvironment get current => isInternal ? AppEnvironment.internal : AppEnvironment.production;
}
