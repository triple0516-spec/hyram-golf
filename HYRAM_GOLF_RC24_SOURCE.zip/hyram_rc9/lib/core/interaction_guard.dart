
import 'package:flutter/material.dart';

class InteractionGuard {
  bool _busy = false;
  bool get busy => _busy;

  Future<T?> run<T>(BuildContext context, Future<T> Function() action) async {
    if (_busy) return null;
    _busy = true;
    try { return await action(); }
    catch (_) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('처리 중 문제가 발생했어요. 잠시 후 다시 시도해 주세요.')),
        );
      }
      return null;
    } finally { _busy = false; }
  }
}
