
enum IntegrationState { live, sandbox, pendingContract, unavailable }

class CommercialConfig {
  static const appName = 'HYRAM GOLF';
  static const brandLine = 'Golf, personally.';
  static const bool productionPaymentsEnabled = false;
  static const bool productionBookingsEnabled = false;

  static const integrations = <String, IntegrationState>{
    'KPGA': IntegrationState.pendingContract,
    'KLPGA': IntegrationState.pendingContract,
    'Golfzon': IntegrationState.pendingContract,
    'KakaoPay': IntegrationState.pendingContract,
    'TossPay': IntegrationState.pendingContract,
    'CardPG': IntegrationState.pendingContract,
    'SamsungPay': IntegrationState.pendingContract,
    'LINELogin': IntegrationState.pendingContract,
    'NaverLogin': IntegrationState.pendingContract,
    'HealthConnect': IntegrationState.sandbox,
    'HealthKit': IntegrationState.pendingContract,
  };
}
