
class ProLicense {
  final String association; // KPGA
  final String memberType;  // 프로 / 투어프로
  final String memberNumber;
  final String holderName;
  final String status;      // 미등록/검증중/인증완료/반려
  const ProLicense({this.association='KPGA',required this.memberType,required this.memberNumber,required this.holderName,this.status='검증중'});
}

class ClubSpec {
  final String category, brand, model, shaftBrand, shaftModel, flex, grip, memo;
  final double? loft, lie, lengthInch, swingWeightValue, totalWeightG, shaftWeightG, torque;
  final String? kickPoint;
  final int? carryM, totalM;
  const ClubSpec({
    required this.category,required this.brand,required this.model,
    this.shaftBrand='',this.shaftModel='',this.flex='',this.grip='',this.memo='',
    this.loft,this.lie,this.lengthInch,this.swingWeightValue,this.totalWeightG,
    this.shaftWeightG,this.torque,this.kickPoint,this.carryM,this.totalM
  });
}

class UserDataSource {
  final String name; // 직접 입력 / Health Connect / HealthKit / Golfzon / partner
  final bool connected;
  final List<String> scopes;
  const UserDataSource(this.name,this.connected,this.scopes);
}
