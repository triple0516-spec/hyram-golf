enum MemberRole { member, representative, staff }

enum IntegrationState { ready, needsCredentials, connectorOnly }

class MemberProfile {
  final String id;
  final String name;
  final MemberRole role;
  final String provider;
  const MemberProfile({required this.id, required this.name, required this.role, required this.provider});
  bool get isRepresentative => role == MemberRole.representative;
}

class GolfRound {
  final String course;
  final DateTime playedAt;
  final int score;
  final bool autoImported;
  const GolfRound({required this.course, required this.playedAt, required this.score, this.autoImported = false});
}

class IntegrationInfo {
  final String name;
  final IntegrationState state;
  final String description;
  const IntegrationInfo(this.name, this.state, this.description);
}
