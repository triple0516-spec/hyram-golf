# HYRAM GOLF Business RC2 — UX / Touch QA

## 수정
- 회원 상태 문구: `사용가능` → `사용중`.
- 메인 내비게이션 5개 → 4개: HOME / BOOKING / RANGE / MY HYRAM.
- HOME의 주요 카드/빠른 실행에 실제 onTap/navigation 연결.
- MY DRIVING RANGE의 모든 주요 카드에 터치 피드백/화면 이동 연결.
- MY HYRAM의 프로 라이선스와 데이터 연결 화면에 실제 navigation 연결.
- 홈 카피를 '기능 소개'보다 '다음 행동' 중심으로 정리.

## 정적 점검 결과
- 기존 Home의 `onTap:(){}` 더미 터치를 제거함.
- Bottom Navigation 목적지를 4개로 단순화함.
- 예약 버튼은 BookingService 호출 유지.
- KPGA/KLPGA 공식 검색은 url_launcher 경로 유지.

## 아직 실제 기기에서 검증해야 하는 항목
- Android back gesture / system back
- 키보드가 입력창을 가리는지
- 360dp 소형 화면 overflow
- TalkBack/접근성 label
- 외부 브라우저 복귀
- 위치 권한 거절/영구 거절
- 네트워크 지연/오프라인
- 결제 취소/중복 탭
- 앱 재실행 시 로그인/회원 상태 유지

이 환경에는 Flutter/Android SDK가 없어 `flutter test` 및 실제 터치 자동화는 실행하지 못함. 따라서 RC2는 코드/정적 UX 점검 완료 상태이며, Play 등록 전 실제 Android 기기 QA가 필수.
