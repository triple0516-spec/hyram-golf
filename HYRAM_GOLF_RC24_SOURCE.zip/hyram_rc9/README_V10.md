# HYRAM GOLF v10 — Interactive Test Source

이번 버전은 **실제 Flutter 화면 이동 + 테스트 회원가입**을 포함합니다.

## 지금 동작하는 것
- 로그인 화면
- 회원가입 4단계
- 필수 약관 동의
- TEST 휴대폰 본인인증 (`123456`)
- 이름 / 이메일 / 비밀번호 입력
- 간편모드 선호 / 프로 여부 선택
- 가입 완료 후 앱 홈으로 이동
- 기존 v8의 홈/부킹/라운드/AI/관리자 화면 이동
- 대표자 테스트 모드 → 관리자 화면

## TEST와 실제 운영의 차이
- 휴대폰 인증은 테스트 코드이며 실제 PASS/NICE 인증이 아닙니다.
- 회원정보는 현재 서버 DB에 영구 저장하지 않습니다.
- 실제 결제/골프존/가맹점 예약은 연결하지 않습니다.
- Google/Kakao/Apple SDK는 운영 키와 서버 토큰 검증이 필요합니다.
- LINE은 connector-only 유지 대상입니다.

## Android에서 실행
Flutter SDK + Android Studio가 설치된 개발 환경에서:
1. `flutter pub get`
2. Android 기기를 USB 디버깅으로 연결
3. `flutter run`
4. APK 테스트 빌드: `flutter build apk --debug`

이 대화 환경에는 Flutter/Android SDK가 없어 APK 자체를 컴파일하지 못했습니다.
