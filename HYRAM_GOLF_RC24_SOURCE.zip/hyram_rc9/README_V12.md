# HYRAM GOLF v12 Dual Association Build
프로 라이선스 등록을 KPGA + KLPGA 이중 구조로 수정했습니다.
KLPGA 선택 시 한국여자프로골프협회 공식 선수 검색으로 바로 이동하는 버튼이 포함됩니다.
`flutter pub get` 후 실행하세요.
