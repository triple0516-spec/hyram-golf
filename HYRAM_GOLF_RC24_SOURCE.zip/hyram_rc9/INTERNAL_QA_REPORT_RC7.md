# HYRAM GOLF RC7 Internal QA

## Rule
Only executed/observed evidence can be PASS. BLOCKED and NOT TESTED never count as PASS.

## Current verified counts
- PASS: 10
- FAIL: 0
- BLOCKED: 6
- NOT TESTED: 5

## Static source gate
- Bracket-balance issues: 0
- Blocking-pattern hits: 0
- Static FAIL: 0

## Corrections made during this sweep
1. HOME no longer fabricates BLACK · PRO for a newly created QA member; it starts SILVER.
2. Admin revenue/success-rate demo numbers are removed; unconnected values show 연결 전/측정 전.
3. Location/Health/SOS/vehicle toggles no longer visually claim a permission/service was enabled.
4. Data download/account delete rows now respond and disclose that the live account API is not connected.
5. PRO form no longer silently ignores missing fields.
6. Checkout can exercise SUCCESS/CANCELLED/FAILED/TIMEOUT/PENDING/DUPLICATE sandbox outcomes.
7. Added Flutter integration-test source for login → HOME → BOOKING → checkout → RANGE → MY HYRAM.
8. Added discount edge-case tests.

## Important
FAIL is currently zero only for the checks that were actually executable here.
Compile/device/live-service gates remain BLOCKED or NOT TESTED, not PASS.
