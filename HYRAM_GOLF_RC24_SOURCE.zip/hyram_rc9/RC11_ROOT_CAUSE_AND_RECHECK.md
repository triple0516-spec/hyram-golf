# RC11 root cause and recheck

## Confirmed causes
1. Flutter, Dart and adb are absent from this execution environment, so compilation and Android runtime gates cannot run here. The uploaded archive also has no generated Android host.
2. Internal auth tests require HYRAM_ENV=internal, but full gate scripts ran `flutter test test` without that flag, leading to a predictable auth test failure when an SDK is present.
3. Production checkout displayed internal QA outcomes and a hardcoded TEST-Q-001 quote; production signup allowed progress into an unusable QA-only flow; AI and round screens invented observations, fixed in RC10.
4. The external provider APIs, credentials and physical Galaxy device remain unavailable, so release readiness cannot be inferred from source checks.

## Corrections
- Aligned shell/PowerShell/bootstrap unit tests with HYRAM_ENV=internal; added production sandbox override regression coverage.
- Hid sample quote, payment methods and QA outcome controls in production and disabled the payment action. Disabled QA signup progression in production and removed QA code disclosure there.
- Preserved RC10 fixes for fabricated AI/round results and production sandbox override.

## Rerun evidence
- bash -n tool/full_internal_gate.sh tool/bootstrap_android.sh: PASS.
- Targeted source assertions after changes: PASS.
- flutter analyze/test/build: BLOCKED (flutter and dart absent). Native/physical Galaxy/provider tests: NOT TESTED.

Do not mark app/release P0 PASS until the executable gates and external integrations are rerun successfully with actual evidence.
